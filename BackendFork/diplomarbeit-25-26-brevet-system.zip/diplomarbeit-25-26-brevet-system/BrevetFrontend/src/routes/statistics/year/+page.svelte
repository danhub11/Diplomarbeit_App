<script>
    import { onMount } from "svelte";
    const { data } = $props();
    let stats = $state();
    let year = $state(2025);
    async function loadStats() {
        try {
            const response = await fetch(
                `http://localhost:5000/Statistics/Year/${year}`,
            );
            if (!response.ok) {
                const err = await response.text();
                throw new Error(err);
            }
            stats = await response.json();
            console.log(stats);
        } catch (err) {
            console.log(err);
        }
    }

    function loadYearStats() {
        loadStats();
    }

    onMount(() => {
        loadStats();
    });
</script>

<input
    class="w-32 border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600 placeholder-gray-500"
    type="number"
    placeholder="Jahr eingeben"
    bind:value={year}
    oninput={loadYearStats}
/>
<table class="table-auto w-full border-collapse">
    <thead>
        <tr class="bg-gray-100 text-left">
            <th class="p-2">Jahr</th>
            <th class="p-2">Finisher</th>
            <th class="p-2">200 km</th>
            <th class="p-2">300 km</th>
            <th class="p-2">400 km</th>
            <th class="p-2">600 km</th>
            <th class="p-2">1000 km</th>
            <th class="p-2">Summe km</th>
        </tr>
    </thead>
    <tbody>
        {#if stats}
            <tr class="border-b">
                <td class="p-2">{stats.year}</td>
                <td class="p-2">{stats.finisher}</td>
                <td class="p-2">{stats.twoHundresKm}</td>
                <td class="p-2">{stats.threeHundresKm}</td>
                <td class="p-2">{stats.fourHundresKm}</td>
                <td class="p-2">{stats.sixHundresKm}</td>
                <td class="p-2">{stats.thousandKm}</td>
                <td class="p-2">{stats.kilometerSum}</td>
            </tr>
        {/if}
    </tbody>
</table>
