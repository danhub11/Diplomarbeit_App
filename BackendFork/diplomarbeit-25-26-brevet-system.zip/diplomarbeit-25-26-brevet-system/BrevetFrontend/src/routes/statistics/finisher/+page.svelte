<script>
    import { onMount } from "svelte";
    let stats = {};
    let fullStats = {};
    let total = 0;
    let search;
    let isSeachring = false;
    async function loadStats() {
        try {
            const response = await fetch(
                "http://localhost:5000/Statistics/Finisher",
            );
            if (!response.ok) {
                const err = await response.text();
                throw new Error(err);
            }
            stats = await response.json();
            fullStats = stats;
            total = Object.values(stats).reduce((a, b) => a + b, 0);
        } catch (err) {
            console.log(err);
        }
    }

    function searchYear() {
        if (!search || search === 0) {
            stats = fullStats;
            isSeachring = false;
        } else {
            isSeachring = true;
            const filteredEntries = Object.entries(fullStats).filter(
                ([year, value]) => year.includes(search.toString()),
            );
            stats = Object.fromEntries(filteredEntries);
        }
    }

    onMount(() => {
        loadStats();
    });
</script>

<h2 class="text-xl font-semibold mb-4">Statistik nach Finisher / Jahr</h2>
<input
    class="w-full sm:w-1/2 border border-red-600 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600 placeholder-gray-500"
    type="number"
    bind:value={search}
    placeholder="Suche Jahr ..."
    oninput={searchYear}
/>
<table class="table-auto w-full border-collapse">
    <thead>
        <tr class="bg-gray-100 text-left">
            <th class="p-2">Jahr</th>
            <th class="p-2">Finisher</th>
            <th class="p-2 w-1/2">Verteilung</th>
        </tr>
    </thead>
    <tbody>
        {#each Object.entries(stats) as [year, value]}
            <tr class="border-b">
                <td class="p-2">{year}</td>
                <td class="p-2">{value}</td>
                <td class="p-2">
                    <div
                        class="bar"
                        style={`--w:${((value / total) * 100).toFixed(2)}%`}
                        title={`${((value / total) * 100).toFixed(1)}%`}
                    ></div>
                </td>
            </tr>
        {/each}
        {#if !isSeachring}
            <tr class="border-b">
                <td class="p-2 font-mono">Summe</td>
                <td class="p-2 font-mono">{total}</td>
                <td class="p-2">
                    <div
                        class="bar"
                        style={`--w:${total.toFixed(2)}%`}
                        title={`${(total * 100).toFixed(1)}%`}
                    ></div>
                </td>
            </tr>
        {/if}
    </tbody>
</table>

<style>
    .bar {
        background: linear-gradient(
            to right,
            #3b82f6 var(--w),
            #e5e7eb var(--w)
        );
        height: 1rem;
        border-radius: 4px;
    }
</style>
