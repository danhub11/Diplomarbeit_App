<script>
    import { onMount } from "svelte";
    import { countryMap, getFlagUrl } from "$lib/countryMap.js";

    let stats = {};
    let fullStats = {};
    let total = 0;
    let search;
    let isLocal = false;
    async function loadStatistics() {
        try {
            const response = await fetch(
                "http://localhost:5000/Statistics/Starter",
            );
            if (!response.ok) throw new Error(await response.text());
            const data = await response.json();

            stats = Object.fromEntries(
                Object.entries(data).filter(([key]) => key !== "Summe"),
            );
            fullStats = stats;

            total = Object.values(stats).reduce((a, b) => a + b, 0);
            console.log(stats);
        } catch (err) {
            console.error("Fehler beim Laden:", err);
        }
    }

    function filterStats() {
        if (!search || search === "") {
            stats = fullStats;
        } else {
            const filteredEntries = Object.entries(fullStats).filter(
                ([code, value]) => code.includes(search.toString()),
            );
            stats = Object.fromEntries(filteredEntries);
        }
    }

    function settingsChanged() {
        if (isLocal) {
            const federalStates = [
                "W",
                "NÖ",
                "OÖ",
                "ST",
                "T",
                "V",
                "K",
                "B",
                "S",
            ];
            stats = Object.fromEntries(
                Object.entries(fullStats).filter(([code]) =>
                    federalStates.includes(code),
                ),
            );
            total = Object.values(stats).reduce((a, b) => a + b, 0);
        } else {
            stats = fullStats;
            total = Object.values(stats).reduce((a, b) => a + b, 0);
        }
    }

    onMount(loadStatistics);
</script>

<h2 class="text-xl font-semibold mb-4">Statistik nach (Bundes-)Land</h2>

<input
    placeholder="Nach Kürzel suchen ..."
    class="w-full sm:w-1/2 border border-red-600 rounded px-4 py-2 mb-6 focus:outline-none focus:ring-2 focus:ring-red-600 placeholder-gray-500"
    type="text"
    bind:value={search}
    oninput={filterStats}
/>

<div class="flex items-center gap-6">
    <p class="p-2">International</p>

    <label class="relative inline-flex items-center cursor-pointer">
        <input
            type="checkbox"
            class="sr-only peer"
            bind:checked={isLocal}
            onchange={settingsChanged}
        />
        <div
            class="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-red-500 rounded-full peer peer-checked:bg-red-600 transition-colors duration-300"
        ></div>
        <div
            class="absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-300 peer-checked:translate-x-full"
        ></div>
    </label>

    <p class="p-2">Bundesländer</p>
</div>

<table class="table-auto w-full border-collapse">
    <thead>
        <tr class="bg-gray-100 text-left">
            <th class="p-2">Kürzel</th>
            <th class="p-2">Land</th>
            <th class="p-2">Flagge</th>
            <th class="p-2">Anzahl</th>
            <th class="p-2 w-1/2">Verteilung</th>
        </tr>
    </thead>
    <tbody>
        {#each Object.entries(stats) as [code, value]}
            <tr class="border-b">
                <td class="p-2 font-mono">{code}</td>
                {#if code === "-"}
                    <td class="p-2">Sonstiges</td>
                {:else}
                    <td class="p-2">{countryMap[code]}</td>
                {/if}
                <td class="p-2">
                    {#if getFlagUrl(code)}
                        <img
                            src={getFlagUrl(code)}
                            alt="Flagge {code}"
                            class="w-6 h-auto inline"
                        />
                    {/if}
                </td>
                <td class="p-2">{value}</td>
                <td class="p-2">
                    <div
                        class="bar"
                        style={`--w:${((value / total) * 100).toFixed(2)}%`}
                        title={`${((value / total) * 100).toFixed(1)}%`}
                    ></div>
                </td>
            </tr>
        {/each}

        <tr class="border-b">
            <td class="p-2 font-mono"></td>
            <td class="p-2 font-mono"></td>
            <td class="p-2 font-mono">Summe</td>
            <td class="p-2 font-mono">{total}</td>
            <td class="p-2">
                <div
                    class="bar"
                    style={`--w:${total.toFixed(2)}%`}
                    title={`${(total * 100).toFixed(1)}%`}
                ></div>
            </td>
        </tr>
    </tbody>
</table>

<style>
    .bar {
        background: linear-gradient(
            to right,
            #3b82f6 var(--w),
            #e5e7eb var(--w)
        );
        height: 1rem;
        border-radius: 4px;
    }
</style>
