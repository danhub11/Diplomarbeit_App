<script>
    import { accountId } from "$lib/share-store";
    import { onMount } from "svelte";
    let isAdmin = $state();
    let randonneurs = $state([]);
    let fullRandonneurs = $state([]);
    let search = $state("");
    let selectedRowId = $state(null);
    let message = $state("");
    let error = $state("");
    let isEditing = $state(false);
    let isEditingId = $state(null);
    let selected = $state(null);
    let statusFilter = $state("all");
    let info = $state();
    let infoRandonneurId = $state(null);
    onMount(() => {
        checkIsAdmin();
        loadRandonneurs();
    });

    async function checkIsAdmin() {
        const token = localStorage.getItem("token");
        if (!token) return;
        try {
            const response = await fetch(
                `http://localhost:5000/Accounts/IsAdmin`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                },
            );
            if (!response.ok) throw new Error(await response.text());
            isAdmin = await response.json();
        } catch (err) {
            console.log(err);
        }
    }

    async function loadRandonneurs() {
        try {
            const res = await fetch("http://localhost:5000/Randonneurs/all");
            if (!res.ok) throw new Error(await res.text());
            const data = await res.json();

            fullRandonneurs = [...data];
            filterRandonneurs();
        } catch (err) {
            error = err.message;
        }
    }

    function filterRandonneurs() {
        const q = search.trim().toLowerCase();

        randonneurs = fullRandonneurs.filter((r) => {
            const matchesSearch =
                (r.firstname || "").toLowerCase().includes(q) ||
                (r.lastname || "").toLowerCase().includes(q) ||
                (r.city || "").toLowerCase().includes(q) ||
                (r.country || "").toLowerCase().includes(q) ||
                (r.email || "").toLowerCase().includes(q);

            const matchesStatus =
                statusFilter === "all" ||
                (statusFilter === "locked" && r.isLocked) ||
                (statusFilter === "unlocked" && !r.isLocked);

            return matchesSearch && matchesStatus;
        });
    }

    function editRow(r) {
        isEditingId = r.id;
        selected = JSON.parse(JSON.stringify(r));
        selectedRowId = selected.id;
        isEditing = true;
        message = "";
        error = "";
    }

    function cancelEdit() {
        isEditingId = null;
        isEditing = false;
        selectedRowId = null;
        selected = null;
    }

    async function saveRandonneur(r) {
        const duplicate = fullRandonneurs.find(
            (x) => x.email === selected.email && x.id !== selected.id,
        );

        if (duplicate) {
            error = "Diese E-Mail-Adresse wird bereits verwendet.";
            return;
        }

        const params = new URLSearchParams();
        params.append("id", r.id);
        if (r.firstname) params.append("Firstname", r.firstname);
        if (r.lastname) params.append("Lastname", r.lastname);
        if (r.address) params.append("Address", r.address);
        if (r.plz) params.append("PLZ", r.plz);
        if (r.city) params.append("City", r.city);
        if (r.country) params.append("Country", r.country);
        if (r.email) params.append("Email", r.email);
        if (r.phoneNumber) params.append("PhoneNumber", r.phoneNumber);

        try {
            const res = await fetch(
                `http://localhost:5000/Randonneurs?${params}`,
                {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(selected),
                },
            );
            if (!res.ok) throw new Error(await res.text());
            message = "Randonneur gespeichert!";
            cancelEdit();
            await loadRandonneurs();
            search = "";
        } catch (err) {
            error = err.message;
        }
    }

    async function checkAccount(randonneurId, accountId, isLocked) {
        if (accountId != -1) {
            info = "";
            infoRandonneurId = null;
            console.log("isADmin: " + isAdmin);
            if (isLocked) {
                await unlockAccount(accountId);
            } else {
                await lockAccount(accountId);
            }
        } else {
            info =
                "Sperren fehlgeschlagen - dieser Randonneur hat noch keinen Account!";
            infoRandonneurId = randonneurId;
            console.log("Account not found");
            setTimeout(() => {
                info = "";
            }, 3000);
        }
    }

    async function lockAccount(accountId) {
        console.log("In lock id: " + accountId);
        const payload = {
            id: accountId,
            IsLocked: true,
        };

        try {
            const token = localStorage.getItem("token");
            const res = await fetch(
                `http://localhost:5000/Accounts/${accountId}/Lock`,
                {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify(payload),
                },
            );
            if (!res.ok) throw new Error(await res.text());
            await loadRandonneurs();
        } catch (err) {
            error = err.message;
        }
    }

    async function unlockAccount(accountId) {
        const payload = {
            id: accountId,
            IsLocked: false,
        };

        const token = localStorage.getItem("token");
        try {
            const res = await fetch(
                `http://localhost:5000/Accounts/${accountId}/Unlock`,
                {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify(payload),
                },
            );
            if (!res.ok) throw new Error(await res.text());
            await loadRandonneurs();
        } catch (err) {
            error = err.message;
        }
    }
</script>

{#if isAdmin}
    <div class="min-h-screen bg-white text-black px-6 py-10">
        <div class="max-w-6xl mx-auto space-y-6">
            <h1 class="text-3xl font-bold text-black-600">
                Teilnehmer Verwaltung
            </h1>

            <div class="flex flex-col sm:flex-row sm:items-center gap-4">
                <input
                    type="text"
                    class="w-full sm:w-1/2 border border-red-600 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600 placeholder-gray-500"
                    placeholder="Suche nach Namen, Ort, Land..."
                    bind:value={search}
                    oninput={filterRandonneurs}
                />

                <select
                    class="w-full sm:w-auto border border-red-600 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600 text-gray-700"
                    bind:value={statusFilter}
                    onchange={filterRandonneurs}
                >
                    <option value="all">Alle</option>
                    <option value="unlocked">Nur aktive</option>
                    <option value="locked">Nur gesperrte</option>
                </select>
            </div>

            <div
                class="overflow-x-auto rounded-lg shadow border border-gray-300 mt-4"
            >
                <table class="min-w-full table-auto text-sm text-left">
                    <thead class="bg-red-600 text-white">
                        <tr>
                            <th class="px-4 py-2">Nachname</th>
                            <th class="px-4 py-2">Vorname</th>
                            <th class="px-4 py-2">Ort</th>
                            <th class="px-4 py-2">Land</th>
                            <th class="px-4 py-2">Email</th>
                            <th class="px-4 py-2">Gesperrt?</th>
                            <th class="px-4 py-2">Aktion</th>
                        </tr>
                    </thead>
                    <tbody>
                        {#each randonneurs as r}
                            <tr class="border-t hover:bg-gray-100 transition">
                                <td class="px-4 py-2">{r.lastname}</td>
                                <td class="px-4 py-2">{r.firstname}</td>
                                <td class="px-4 py-2">{r.city}</td>
                                <td class="px-4 py-2">{r.country}</td>
                                <td class="px-4 py-2">{r.email}</td>
                                <td class="px-4 py-2">
                                    {#if r.isLocked}
                                        <button
                                            type="button"
                                            onclick={() =>
                                                checkAccount(
                                                    r.id,
                                                    r.accountId,
                                                    r.isLocked,
                                                )}
                                            class="text-red-600 hover:text-red-700 transition duration-150 px-2 py-1 rounded border border-red-600 hover:bg-red-50"
                                            title="Konto ist gesperrt – Klicken zum Entsperren"
                                        >
                                            Gesperrt
                                        </button>
                                    {:else}
                                        <button
                                            type="button"
                                            onclick={() =>
                                                checkAccount(
                                                    r.id,
                                                    r.accountId,
                                                    r.isLocked,
                                                )}
                                            class="text-green-600 hover:text-green-700 transition duration-150 px-2 py-1 rounded border border-green-600 hover:bg-green-50"
                                            title="Konto ist aktiv – Klicken zum Sperren"
                                        >
                                            Aktiv
                                        </button>
                                    {/if}
                                </td>
                                <td class="px-4 py-2">
                                    <button
                                        class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                                        onclick={() => editRow(r)}
                                    >
                                        Bearbeiten
                                    </button>
                                </td>
                            </tr>
                            {#if info && infoRandonneurId == r.id}
                                <tr>
                                    <td
                                        colspan="7"
                                        class="px-4 py-2 text-red-600 font-semibold bg-yellow-100"
                                    >
                                        {info}</td
                                    >
                                </tr>
                            {/if}
                            {#if isEditingId === r.id}
                                <tr class="bg-gray-100 border-b">
                                    <td colspan="7" class="px-4 py-6">
                                        <div
                                            class="grid grid-cols-1 sm:grid-cols-2 gap-4"
                                        >
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={selected.firstname}
                                                placeholder="Vorname"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={selected.lastname}
                                                placeholder="Nachname"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={
                                                    selected.dateOfBirth
                                                }
                                                placeholder="Geburtsdatum"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={selected.address}
                                                placeholder="Adresse"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={selected.city}
                                                placeholder="Ort"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={selected.PLZ}
                                                placeholder="PLZ"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={selected.country}
                                                placeholder="Land"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={selected.email}
                                                placeholder="Email"
                                            />
                                            <input
                                                class="border border-red-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                bind:value={
                                                    selected.phoneNumber
                                                }
                                                placeholder="Telefonnummer"
                                            />
                                        </div>

                                        <div class="mt-4 flex flex-wrap gap-4">
                                            <button
                                                class="bg-green-600 text-white px-5 py-2 rounded hover:bg-green-700"
                                                onclick={() =>
                                                    saveRandonneur(selected)}
                                                >Speichern</button
                                            >
                                            <button
                                                class="bg-gray-500 text-white px-5 py-2 rounded hover:bg-gray-600"
                                                onclick={cancelEdit}
                                                >Abbrechen</button
                                            >
                                        </div>

                                        {#if message}
                                            <p class="text-green-700 mt-4">
                                                {message}
                                            </p>
                                        {/if}
                                        {#if error}
                                            <p class="text-red-600 mt-4">
                                                {error}
                                            </p>
                                        {/if}
                                    </td>
                                </tr>
                            {/if}
                        {/each}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
{:else}
    <p>Sie haben nicht die Rechte um diese Seite zu sehen</p>
{/if}
