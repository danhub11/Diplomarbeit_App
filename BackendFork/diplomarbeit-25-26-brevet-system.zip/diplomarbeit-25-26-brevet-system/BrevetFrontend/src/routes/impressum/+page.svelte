<script>
</script>

<div class="max-w-5xl mx-auto my-10 p-8 bg-white rounded-xl shadow-md text-black">
	<h1 class="text-4xl font-bold text-black mb-8 text-center">Impressum</h1>

	<section class="space-y-6 text-sm sm:text-base leading-relaxed">
		<div>
			<h2 class="font-semibold text-lg text-gray-800 mb-1">Angaben gemäß §5 ECG, §14 UGB, §63 GewO & §25 MedienG</h2>
			<p>Ferdinand Jung</p>
			<p>Wohnpark 18g<br />4053 Haid, Österreich</p>
			<p class="mt-2">
				E-Mail:
				<a href="mailto:Ferdinand.jung@randonneurs-austria.at" class="text-red-700 hover:underline">
					Ferdinand.jung@randonneurs-austria.at
				</a>
			</p>
			<p class="text-gray-500 text-sm mt-1">
				Quelle: Erstellt mit dem Impressum Generator von firmenwebseiten.at in Kooperation mit talks.at
			</p>
		</div>

		<div>
			<h2 class="font-semibold text-lg text-gray-800 mb-1">EU-Streitschlichtung</h2>
			<p>
				Gemäß Verordnung über Online-Streitbeilegung in Verbraucherangelegenheiten (ODR-Verordnung)
				möchten wir Sie über die Online-Streitbeilegungsplattform (OS-Plattform) informieren.
			</p>
			<p>
				Verbraucher haben die Möglichkeit, Beschwerden an die Online-Streitbeilegungsplattform der
				Europäischen Kommission unter&nbsp;
				<a href="http://ec.europa.eu/odr?tid=221085938" target="_blank" class="text-red-700 hover:underline">
					http://ec.europa.eu/odr?tid=221085938
				</a>
				&nbsp;zu richten.
			</p>
			<p>Die dafür notwendigen Kontaktdaten finden Sie oberhalb in unserem Impressum.</p>
			<p class="mt-2">
				Wir möchten Sie jedoch darauf hinweisen, dass wir nicht bereit oder verpflichtet sind, an
				Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
			</p>
		</div>

		<div>
			<h2 class="font-semibold text-lg text-gray-800 mb-1">Haftung für Inhalte dieser Webseite</h2>
			<p>
				Wir entwickeln die Inhalte dieser Webseite ständig weiter und bemühen uns, korrekte und
				aktuelle Informationen bereitzustellen. Leider können wir keine Haftung für die Korrektheit
				aller Inhalte übernehmen – speziell für jene, die seitens Dritter bereitgestellt wurden.
			</p>
			<p>
				Sollten Ihnen problematische oder rechtswidrige Inhalte auffallen, bitten wir Sie, uns
				umgehend zu kontaktieren – Sie finden die Kontaktdaten oben.
			</p>
		</div>

		<div>
			<h2 class="font-semibold text-lg text-gray-800 mb-1">Haftung für Links auf dieser Webseite</h2>
			<p>
				Unsere Webseite enthält Links zu anderen Webseiten, für deren Inhalt wir nicht verantwortlich
				sind. Haftung für verlinkte Websites besteht laut § 17 ECG für uns nicht, da wir keine
				Kenntnis rechtswidriger Tätigkeiten hatten und haben. Sollte uns eine Rechtswidrigkeit bekannt
				werden, entfernen wir die betreffenden Links sofort.
			</p>
			<p>
				Wenn Ihnen rechtswidrige Links auf unserer Website auffallen, kontaktieren Sie uns bitte –
				Kontaktdaten finden Sie im Impressum.
			</p>
		</div>

		<div>
			<h2 class="font-semibold text-lg text-gray-800 mb-1">Urheberrechtshinweis</h2>
			<p>
				Alle Inhalte dieser Webseite (Bilder, Fotos, Texte, Videos) unterliegen dem Urheberrecht.
				Falls notwendig, werden wir die unerlaubte Nutzung von Teilen der Inhalte unserer Seite
				rechtlich verfolgen.
			</p>
		</div>

		<div>
			<h2 class="font-semibold text-lg text-gray-800 mb-1">Bildernachweis</h2>
			<p>
				Die Bilder, Fotos und Grafiken auf dieser Webseite sind urheberrechtlich geschützt.
				<br />
				Die Bildrechte liegen bei:
			</p>
			<ul class="list-disc pl-5 mt-1">
				<li>Ferdinand Jung – Randonneurs Austria</li>
			</ul>
		</div>
	</section>
</div>
