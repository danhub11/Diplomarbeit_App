<script>
    import { accountId } from "$lib/share-store";
    import { onMount, onDestroy } from "svelte";

    let visibilitySetting = $state();
    let isAdmin = $state(false);
    let info = $state();

    let visibilityOptions = [
        "für alle",
        "nur für eingeloggte User",
        "nur für Teilnehmer des Brevets"
    ];

    let visibilityOpen = $state(false);
    let dropdownRef = $state();

    function toggleDropdown() {
        visibilityOpen = !visibilityOpen;
    }

    function selectVisibility(option) {
        visibilitySetting = option;
        visibilityOpen = false;
    }

    async function checkIsAdmin() {
        const token = localStorage.getItem("token");
        if(!token) return;
        try{
            const response = await fetch(`http://localhost:5000/Accounts/IsAdmin`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            if(!response.ok) throw new Error(await response.text());
            isAdmin = await response.json();
        } catch(err){
            console.log(err);
        }
    }

    async function loadSettings() {
        try {
            const response = await fetch("http://localhost:5000/Settings/Get");
            if (!response.ok) throw new Error(await response.text());
            let responseBody = await response.json();
            visibilitySetting = responseBody.setting;
        } catch (err) {
            console.error(err);
        }
    }

    async function btnSaveClicked() {
        const payload = {
            SettingId: 1,
            AccountId: $accountId,
            Setting: visibilitySetting,
        };
        try {
            const response = await fetch(`http://localhost:5000/Settings/Update?settingId=1&accountId=${$accountId}&setting=${visibilitySetting}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            if (!response.ok) throw new Error(await response.text());
            info = "✅ Erfolgreich gespeichert!";
            setTimeout(() => (info = ""), 2000);
        } catch (err) {
            console.error(err);
        }
    }

    function handleClickOutside(event) {
        if (visibilityOpen && dropdownRef && !dropdownRef.contains(event.target)) {
            visibilityOpen = false;
        }
    }

    onMount(async () => {
        await checkIsAdmin();
        await loadSettings();

        window.addEventListener("click", handleClickOutside);
    });

    onDestroy(() => {
        window.removeEventListener("click", handleClickOutside);
    });
</script>


<main class="max-w-2xl mx-auto p-8 bg-white rounded-lg shadow-md mt-10 border border-gray-200">
    <h1 class="text-2xl font-bold text-black mb-6">Admin-Einstellungen</h1>

    {#if isAdmin}
        <div>
            <label for="visibilitySetting" class="block text-sm font-medium text-gray-700 mb-1">
                Sichtbarkeit der Starterlisten
            </label>
            <div class="relative w-full" bind:this={dropdownRef}>
                <button
                    type="button"
                    onclick={toggleDropdown}
                    class="w-full border border-gray-300 rounded-lg p-2 text-sm text-left bg-white
                    focus:outline-none focus:ring-1 focus:ring-red-700 focus:border-red-700"
                >
                    {visibilitySetting}
                    <span class="float-right">&#x25BC;</span>
                </button>

                {#if visibilityOpen}
                    <ul
                        class="absolute z-10 w-full mt-1 bg-white rounded-lg max-h-40 overflow-auto text-sm shadow-md border border-gray-200"
                    >
                        {#each visibilityOptions as option}
                            <li>
                                <button
                                    type="button"
                                    class="w-full text-left px-4 py-2 hover:bg-red-100 hover:text-black cursor-pointer"
                                    onclick={() => selectVisibility(option)}
                                >
                                    {option}
                                </button>
                            </li>
                        {/each}
                    </ul>
                {/if}
            </div>
        </div>

        <button
            onclick={btnSaveClicked}
            class="mt-4 bg-red-700 hover:bg-red-800 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200"
        >
            Speichern
        </button>

        {#if info}
            <p class="mt-4 text-green-600 font-medium">{info}</p>
        {/if}
    {:else}
        <p class="text-red-600 font-semibold">
            ❌ Sie sind nicht berechtigt, diese Einstellungen zu ändern!
        </p>
    {/if}
</main>
