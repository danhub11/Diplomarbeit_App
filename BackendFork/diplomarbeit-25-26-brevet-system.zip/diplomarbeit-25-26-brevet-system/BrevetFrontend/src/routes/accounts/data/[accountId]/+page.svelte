<script>
	import { onMount } from "svelte";
	import { accountId } from "$lib/share-store";

	let profilbild = $state();
	let previewUrl = $state();
	let selectedFile;
	let fileInput;
	let showUploadBtn = $state(false);

	let firstname = $state();
	let lastname = $state();
	let dateOfBirth = $state();
	let address = $state();
	let plz = $state();
	let city = $state();
	let country = $state();
	let email = $state();
	let phoneNumber = $state();
	let info = $state();
	let loginId = $state();
	let isLoading = $state(true);
	let showModal = $state(false);


	const fieldConfigs = [
		{
			id: "firstname",
			label: "Vorname",
			type: "text",
			value: () => firstname,
			setter: (v) => (firstname = v),
		},
		{
			id: "lastname",
			label: "Nachname",
			type: "text",
			value: () => lastname,
			setter: (v) => (lastname = v),
		},
		{
			id: "birthdate",
			label: "Geburtsdatum",
			type: "date",
			value: () => dateOfBirth,
			setter: (v) => (dateOfBirth = v),
		},
		{
			id: "address",
			label: "Adresse",
			type: "text",
			value: () => address,
			setter: (v) => (address = v),
		},
		{
			id: "plz",
			label: "PLZ",
			type: "number",
			value: () => plz,
			setter: (v) => (plz = v),
		},
		{
			id: "city",
			label: "Stadt",
			type: "text",
			value: () => city,
			setter: (v) => (city = v),
		},
		{
			id: "country",
			label: "Bundesland",
			type: "text",
			value: () => country,
			setter: (v) => (country = v),
		},
		{
			id: "email",
			label: "E-Mail",
			type: "email",
			value: () => email,
			setter: (v) => (email = v),
		},
		{
			id: "phoneNumber",
			label: "Telefon",
			type: "tel",
			value: () => phoneNumber,
			setter: (v) => (phoneNumber = v),
		},
	];

	function loadStorage() {
		const stored = localStorage.getItem("LoginId");
		if (stored) loginId = stored;
	}

	async function loadAccountAfterRefresh() {
		const token = localStorage.getItem("token");
		if (!token) return;
		try {
			const payload = JSON.parse(atob(token.split(".")[1]));
			accountId.set(Number(payload.sub)); // => sub = user id
		} catch (err) {
			console.log("Token ist abgelaufen oder ungültig", err);
			loadStorage.removeItem("token");
			accountId.set(null);
		}
	}

	async function loadCurrentData() {
		const token = localStorage.getItem("token");
		if (!token) return;

		try {
			const response = await fetch(
				"http://localhost:5000/Accounts/profile",
				{
					headers: {
						Authorization: `Bearer ${token}`,
					},
				},
			);
			if (!response.ok) throw new Error(await response.text());
			const body = await response.json();
			firstname = body.firstname;
			lastname = body.lastname;
			dateOfBirth = body.dateOfBirth?.split("T")[0];
			address = body.address;
			plz = body.plz;
			city = body.city;
			country = body.country;
			email = body.email;
			profilbild = body.profileImagePath
			? `http://localhost:5000${body.profileImagePath}?t=${Date.now()}`
			: "/Profil.png";
			phoneNumber = body.phoneNumber;
		} catch (err) {
			console.log(err);
		}
	}

	function onFileChange(event) {
		const file = event.target.files[0];
		if (file) {
			selectedFile = file;
			previewUrl = URL.createObjectURL(file);
			showUploadBtn = true;
		}
	}

	async function uploadProfileImage() {
		if (!selectedFile) return;

		console.log(profilbild);

		const formData = new FormData();
		formData.append("image", selectedFile);

		const res = await fetch(
			`http://localhost:5000/Accounts/${$accountId}/UploadProfileImage`,
			{
				method: "POST",
				body: formData,
			},
		);

		if (res.ok) {
			info = "Profilbild erfolgreich hochgeladen!";
			showUploadBtn = false;

			// Daten neu laden mit neuem Pfad
			await loadCurrentData();
		} else {
			info = await res.text();
		}
	}

	async function btnSaveClicked() {
		const birthDate = new Date(dateOfBirth);
		if (birthDate > new Date()) {
			info = "Geburtsdatum darf nicht in der Zukunft liegen!";
			return;
		}
		if (
			!firstname ||
			!lastname ||
			!dateOfBirth ||
			!plz ||
			!city ||
			!country ||
			!email ||
			!phoneNumber
		) {
			info = "Erforderliche Daten dürfen nicht leer sein!";
			return;
		}

		const token = localStorage.getItem("token");
		if (!token) return;

		const payload = {
			Firstname: firstname,
			Lastname: lastname,
			Address: address,
			PLZ: plz,
			City: city,
			Country: country,
			Email: email,
			PhoneNumber: phoneNumber,
			DateOfBirth: dateOfBirth,
		};
		try {
			const response = await fetch(
				`http://localhost:5000/Accounts/profile`,
				{
					method: "PUT",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${token}`,
					},
					body: JSON.stringify(payload),
				},
			);
			info = response.ok
				? "Daten erfolgreich geändert!"
				: "Daten konnten nicht geändert werden: " +
					(await response.text());
		} catch (err) {
			console.log(err);
		}
	}

	onMount(async () => {
		loadStorage();
		await loadAccountAfterRefresh();
		await loadCurrentData();
		isLoading = false;
	});
</script>

<!-- Seite -->
<div class="min-h-screen bg-white py-10 px-4 text-black">
	<div class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
		<!-- Profilbild -->
		<div
			class="bg-white border border-gray-300 rounded-xl p-6 shadow flex flex-col items-center"
		>
			<div class="relative w-64 h-64 mb-4">
				<div
					class="absolute inset-0 rounded-full border-4 border-red-600 shadow-inner pointer-events-none"
				></div>

				<button
					type="button"
					onclick={() => (showModal = true)}
					class="rounded-full focus:outline-none"
				>
					<img
						src={profilbild}
						alt="Profilbild"
						class="rounded-full w-64 h-64 object-cover"
					/>
				</button>
			</div>

			<input
				type="file"
				accept="image/*"
				bind:this={fileInput}
				onchange={onFileChange}
				class="hidden"
			/>

			<button
				class="text-base text-red-700 hover:underline"
				onclick={() => fileInput.click()}
			>
				Datei auswählen
			</button>

			{#if showUploadBtn}
				<button
					class="mt-2 bg-red-700 hover:bg-red-800 text-white px-4 py-2 rounded-md"
					onclick={uploadProfileImage}
				>
					Upload
				</button>
			{/if}
		</div>

		<!-- Form -->
		<div
			class="bg-white border border-gray-300 rounded-xl p-6 shadow space-y-6"
		>
			<h3 class="text-xl font-semibold border-b border-red-600 pb-2">
				Profildaten bearbeiten
			</h3>
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
				{#each fieldConfigs as field}
					<div>
						<label
							for={field.id}
							class="block text-sm font-medium mb-1"
							>{field.label}</label
						>
						<input
							id={field.id}
							type={field.type}
							value={field.value()}
							oninput={(e) => field.setter(e.target.value)}
							class="w-full border rounded-md px-4 py-2 focus:ring-1 focus:ring-red-700 focus:border-red-700"
						/>
					</div>
				{/each}
			</div>

			<div class="flex justify-between pt-4">
				<a
					href="/accounts/password"
					class="inline-block text-center bg-red-600 text-white font-medium px-4 py-2 rounded-md shadow hover:bg-red-700 transition"
				>
					Passwort ändern
				</a>
				<button
					onclick={btnSaveClicked}
					class="bg-black text-white hover:bg-red-700 transition px-6 py-2 rounded-md font-semibold"
				>
					Speichern
				</button>
			</div>

			{#if info}
				<p class="text-red-600 text-sm mt-2">{info}</p>
			{/if}
		</div>
	</div>
</div>

{#if showModal}
	<div
		class="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50"
	>
		<div class="relative">
			<img
				src={previewUrl || profilbild}
				alt="Großes Profilbild"
				class="max-w-full max-h-screen rounded-lg border-4 border-white shadow-xl"
			/>
			<button
				class="absolute top-2 right-2 text-white text-2xl bg-black bg-opacity-70 rounded-full px-2 hover:bg-red-600"
				onclick={() => (showModal = false)}
			>
				×
			</button>
		</div>
	</div>
{/if}
