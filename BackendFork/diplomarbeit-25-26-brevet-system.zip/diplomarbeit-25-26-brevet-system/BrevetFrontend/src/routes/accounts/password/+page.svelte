<script>
	import { goto } from "$app/navigation";
	import { accountId } from "$lib/share-store";
	let password = $state();
	let passwordCheck = $state();
	let info = $state();

	async function saveBtnClicked() {
		if (password !== passwordCheck) {
			info = "Passwörter stimmen nicht überein!";
			return;
		}

		const token = localStorage.getItem("token");
		if (!token) return;

		const payload = {
			Password: password,
			PasswordCheck: passwordCheck
		};

		try {
			const response = await fetch(
				"http://localhost:5000/Accounts/Password",
				{
					method: "PUT",
					headers: {
						Authorization: `Bearer ${token}`,
						"Content-Type": "application/json"
					},
					body: JSON.stringify(payload),
				},
			);

			if (!response.ok) {
				const err = await response.text();
				info = err;
				throw new Error(err);
			}

			info = "Passwort erfolgreich geändert!";
			setTimeout(() => {
				goto(`/accounts/data/${$accountId}`);
			}, 2000);
		} catch (err) {
			console.log(err);
		}
	}
</script>

<div class="flex justify-center items-center min-h-screen bg-white px-4">
	<div class="w-full max-w-xl">
		<h1 class="text-2xl font-semibold mb-6 text-center">Passwort ändern</h1>

		<div class="mb-6">
			<label for="password" class="block text-lg font-semibold mb-2">Neues Passwort</label>
			<input
				id="password"
				type="password"
				bind:value={password}
				class="w-full border border-gray-300 rounded-lg p-4 text-lg focus:outline-none focus:ring-2 focus:ring-red-700"
				placeholder="Neues Passwort eingeben"
			/>
		</div>

		<div class="mb-6">
			<label for="passwordCheck" class="block text-lg font-semibold mb-2">Passwort wiederholen</label>
			<input
				id="passwordCheck"
				type="password"
				bind:value={passwordCheck}
				class="w-full border border-gray-300 rounded-lg p-4 text-lg focus:outline-none focus:ring-2 focus:ring-red-700"
				placeholder="Passwort wiederholen"
			/>
		</div>

		<div class="flex justify-end mt-8">
			<button
				onclick={saveBtnClicked}
				class="bg-black text-white text-lg px-6 py-3 rounded-lg hover:bg-gray-900"
			>
				Speichern
			</button>
		</div>

		{#if info}
			<p class="text-red-600 mt-6 text-lg">{info}</p>
		{/if}
	</div>
</div>
