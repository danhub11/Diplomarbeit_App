<script>
	import { accountId } from "$lib/share-store";
	import { goto } from "$app/navigation";

	let loginId = $state();
	let password = $state();
	let info = $state();

	async function btnLoginClicked() {
		if (!loginId || !password) {
			info = "Bitte füllen Sie die Felder aus!";
			return;
		}

		info = "";
		const payload = { loginId: loginId.trim(), password: password };

		try {
			const response = await fetch("http://localhost:5000/Accounts/Login", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload)
			});

			if (!response.ok) {
				const error = await response.text();
				info = "Fehler bei der Anmeldung: " + error;
				throw new Error(error);
			}

			const result = await response.json();
			const token = result.token;

			localStorage.setItem("token", token);

			const payloadData = JSON.parse(atob(token.split(".")[1]));
			accountId.set(Number(payloadData.sub)); // -> sub = userId

			alert("Anmeldung erfolgreich!");
			goto("/");
		} catch (err) {
			console.log(err);
		}
	}
</script>

<div class="flex justify-center items-center min-h-screen bg-white px-4">
	<div class="w-full max-w-xl">
		<h1 class="text-2xl font-semibold mb-6 text-center">Login</h1>

		<div class="mb-6">
			<label for="loginId" class="block text-lg font-semibold mb-2">Id</label>
			<input
				id="loginId"
				type="text"
				bind:value={loginId}
				class="w-full border border-gray-300 rounded-lg p-4 text-lg focus:outline-none focus:ring-2 focus:ring-red-700"
			/>
		</div>

		<div class="mb-6">
			<label for="password" class="block text-lg font-semibold mb-2">Passwort</label>
			<div class="relative">
				<input
					id="password"
					type="password"
					bind:value={password}
					class="w-full border border-gray-300 rounded-lg p-4 text-lg focus:outline-none focus:ring-2 focus:ring-red-700"
				/>
				<span class="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-gray-600 cursor-pointer hover:underline">
					Haben Sie Ihr Passwort vergessen?
				</span>
			</div>
		</div>

		<div class="flex items-center justify-between mt-8">
			<button
				onclick={btnLoginClicked}
				class="bg-black text-white text-lg px-6 py-3 rounded-lg hover:bg-gray-900"
			>
				Anmelden
			</button>
			<a href="/register" class="text-lg hover:underline">Registrieren</a>
		</div>

		<p class="text-red-600 mt-6 text-lg">{info}</p>
	</div>
</div>