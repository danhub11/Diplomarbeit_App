<script>
	import { goto } from "$app/navigation";
	import CopyBrevet from "$lib/components/CopyBrevet.svelte";
	import { accountId } from "$lib/share-store";
	import { onMount } from "svelte";

	let isAdmin = $state(false);
	let info = $state("");
	let distance = $state("");
	let date = $state("");
	let town = $state("");
	let loginId = $state("");
	let isLoading = $state(true);
	let isCopingBrevet = $state(false);

	let selectedBrevets = $state([]);
	$inspect(selectedBrevets);
	function loadStorage() {
		const stored = localStorage.getItem("LoginId");
		if (stored) loginId = stored;
	}

	async function loadAccountAfterRefresh() {
		const token = localStorage.getItem("token");
        if(!token) return;
        try {
            const payload = JSON.parse(atob(token.split(".")[1]));
            accountId.set(Number(payload.sub)); // => sub = user id
			await checkIsAdmin();
        } catch (err) {
            console.log("Token ist abgelaufen oder ungültig", err);
            loadStorage.removeItem("token");
            accountId.set(null);
        }
	}

	async function checkIsAdmin() {
        const token = localStorage.getItem("token");
        if(!token) return;
        try{
            const response = await fetch(`http://localhost:5000/Accounts/IsAdmin`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            if(!response.ok) throw new Error(await response.text());
            isAdmin = await response.json();
        } catch(err){
            console.log(err);
        }
    }

	async function addNewBrevetClicked() {
		if (selectedBrevets.length > 0) {
			for (let index = 0; index < selectedBrevets.length; index++) {
				distance = selectedBrevets[index].distance;
				let newDate = new Date(selectedBrevets[index].date);
				newDate.setFullYear(newDate.getFullYear() + 1);
				date = newDate.toISOString().split("T")[0];
				town = selectedBrevets[index].town;

				const payload = { Distance: distance, Date: date, Town: town };
				const response = await fetch(
					"http://localhost:5000/Brevets",
					{
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify(payload),
					},
				);

				if (response.ok) {
					info = "Brevets erfolgreich kopiert!";
					distance = "";
					date = "";
					town = "";
				} else {
					info = await response.text();
				}
			}
			distance = "";
			date = "";
			town = "";
			isCopingBrevet = false;
			selectedBrevets = [];
			return;
		}

		info = "";

		if (!distance || !date || !town) {
			info = "Bitte füllen Sie alle Felder aus!";
			return;
		}

		const today = new Date();
		const choosenDate = new Date(date);
		today.setHours(0, 0, 0, 0);
		choosenDate.setHours(0, 0, 0, 0);

		if (choosenDate <= today) {
			info = "Das Datum muss in der Zukunft liegen!";
			return;
		}

		if (distance < 200) {
			info = "Distanz ist zu kurz!";
			return;
		}

		const payload = { Distance: distance, Date: date, Town: town };
		const response = await fetch("http://localhost:5000/Brevets", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(payload),
		});

		if (response.ok) {
			info = "Neues Brevet erfolgreich gespeichert!";
			distance = "";
			date = "";
			town = "";
		} else {
			info = await response.text();
		}
	}

	function setCopyBrevet() {
		isCopingBrevet = isCopingBrevet ? false : true;
		console.log(isCopingBrevet);
	}

	onMount(async () => {
		loadStorage();
		await loadAccountAfterRefresh();
		isLoading = false;
	});
</script>

{#if isLoading}
	<p class="text-center mt-10">Lade Daten ...</p>
{:else if !$accountId}
	<p class="text-center mt-10 text-red-600">Bitte zuerst einloggen!</p>
{:else if isAdmin}
	<h1 class="text-2xl font-bold text-center mb-8">Neues Brevet anlegen</h1>

	<div
		class="max-w-xl mx-auto border border-gray-300 rounded-xl p-6 shadow-sm space-y-5"
	>
		<div class="space-y-1">
			<label
				for="distance"
				class="block text-sm font-medium text-gray-700"
				>Distanz (in km)</label
			>
			<input
				type="number"
				min="200"
				placeholder="z. B. 200"
				class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-red-500 focus:border-red-500"
				bind:value={distance}
			/>
		</div>

		<div class="space-y-1">
			<label for="date" class="block text-sm font-medium text-gray-700"
				>Datum</label
			>
			<input
				type="date"
				class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-red-500 focus:border-red-500"
				bind:value={date}
			/>
		</div>

		<div class="space-y-1">
			<label for="town" class="block text-sm font-medium text-gray-700"
				>Ort / Stadt</label
			>
			<input
				type="text"
				placeholder="z. B. Wien"
				class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-red-500 focus:border-red-500"
				bind:value={town}
			/>
		</div>

		{#if info}
			<p class="text-red-600 text-sm text-center">{info}</p>
		{/if}

		<button onclick={setCopyBrevet}>Brevet aus dem Vorjahr kopieren</button>

		{#if isCopingBrevet}
			<CopyBrevet bind:selectedBrevets />
		{/if}

		<div class="text-center">
			<button
				class="bg-black hover:bg-gray-800 text-white px-6 py-2 rounded-md transition"
				onclick={addNewBrevetClicked}
			>
				Speichern
			</button>
		</div>
	</div>
{/if}
