<script>
    import { text } from "@sveltejs/kit";
    import { onMount } from "svelte";
    import { get } from "svelte/store";
    import { accountId } from "$lib/share-store";
    import EditBrevet from "$lib/components/EditBrevet.svelte";

    let info = $state("");
    let currentYear = new Date().getFullYear();
    let brevets = $state([]);
    let registeredBrevets = $state(new Map());
    let desiredDates = $state(new Map());
    let isButtonDisabled = $state(false);

    let isAdmin = $state();
    let editingBrevetId = $state(null);
    let deletingBrevetId = $state(null);
    async function loadBrevets(year) {
        try {
            const response = await fetch(
                `http://localhost:5000/Brevets?year=${currentYear}`,
            );
            if (!response.ok) {
                const err = await response.text();
                info = err;
                throw new Error(err);
            }
            const responseBody = await response.json();
            brevets = [...responseBody];
            console.log(brevets);
        } catch (err) {
            console.log(err);
        }
    }

    async function checkIsAdmin() {
        const token = localStorage.getItem("token");
        if(!token) return;
        try{
            const response = await fetch(`http://localhost:5000/Accounts/IsAdmin`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            if(!response.ok) throw new Error(await response.text());
            isAdmin = await response.json();
        } catch(err){
            console.log(err);
        }
    }

    function brevetChecked(id, isChecked) {
        info = "";
        if (isChecked) {
            registeredBrevets.set(id, false);
        } else {
            registeredBrevets.delete(id);
        }
        registeredBrevets = new Map(registeredBrevets);
    }

    function withMedalChecked(id, isChecked) {
        info = "";
        if (!registeredBrevets.has(id)) {
            info = "Bitte zuerst das Brevet aktivieren.";
            return;
        }
        registeredBrevets.set(id, isChecked);
        registeredBrevets = new Map(registeredBrevets);
        info = "";
    }

    function desiredDateChanged(id, date) {
        if (date) {
            desiredDates.set(id, date);
        } else {
            desiredDates.delete(id);
        }
        desiredDates = new Map(desiredDates);
    }

    async function btnRegisterClicked() {
        if (isButtonDisabled) return;
        isButtonDisabled = true;
        if (!$accountId) {
            info = "Bitte zuerst einloggen!";
            return;
        }
        console.log(registeredBrevets);
        registeredBrevets.forEach(async (withMedal, id) => {
            const desiredDateForBrevet = desiredDates.get(id);
            let url = desiredDateForBrevet
                ? `http://localhost:5000/Brevets/Register?brevetId=${id}&accountId=${$accountId}&withMedal=${withMedal}&desiredDate=${desiredDateForBrevet}`
                : `http://localhost:5000/Brevets/Register?brevetId=${id}&accountId=${$accountId}&withMedal=${withMedal}`;

            try {
                const response = await fetch(url, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                });

                if (response.ok) {
                    info = await response.text();
                } else {
                    const err = await response.text();
                    info = "Ein Fehler ist aufgetreten: " + err;
                    throw new Error(err);
                }
            } catch (err) {
                console.log(err);
            }
        });

        setTimeout(() => {
            isButtonDisabled = false;
            info = "";
        }, 2000);
    }

    function btnEditClicked(brevetId) {
        if (editingBrevetId === brevetId) {
            editingBrevetId = null;
        } else {
            editingBrevetId = brevetId;
        }
    }

    function setDelete(brevetId) {
        if (deletingBrevetId === brevetId) {
            deletingBrevetId = null;
        } else {
            deletingBrevetId = brevetId;
        }
    }

    async function btnDeleteClicked(brevetId) {
        const payload = {
            id: brevetId,
        };

        try {
            const response = await fetch(
                `http://localhost:5000/Brevets?id=${brevetId}`,
                {
                    method: "DELETE",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload),
                },
            );
            if (!response.ok) {
                const err = await response.text();
                throw new Error(err);
            }
            info = "Brevet erfolgreich gelöscht!";
            loadBrevets();
            deletingBrevetId = null;
            setTimeout(() => {
                info = "";
            }, 3000);
        } catch (err) {
            console.log(err);
        }
    }

    onMount(() => {
        loadBrevets(currentYear);
        checkIsAdmin();
    });
</script>

<h1 class="text-2xl font-bold text-center mb-8">Brevets {currentYear}</h1>

<div class="max-w-2xl mx-auto space-y-6">
    {#each brevets as brevet, idx}
        <div
            class="border border-gray-300 rounded-xl p-4 shadow-sm space-y-3 transition"
            class:border-red-600={registeredBrevets.has(brevet.id)}
        >
            <div class="flex items-center gap-3">
                <input
                    type="checkbox"
                    id={`brevet-${idx}`}
                    class="h-5 w-5 text-red-600 accent-red-600 focus:outline-none focus:ring-0"
                    checked={registeredBrevets.has(brevet.id)}
                    onchange={(e) => brevetChecked(brevet.id, e.target.checked)}
                />
                <label for={`brevet-${idx}`} class="text-base font-medium">
                    Brevet {brevet.distance} km, {brevet.date.split("T")[0]}, {brevet.town}
                </label>
            </div>

            <div
                class="flex flex-col gap-2 md:flex-row md:items-center md:justify-between"
            >
                <div class="flex items-center gap-2">
                    <input
                        type="checkbox"
                        id={`medaille-${idx}`}
                        class="h-4 w-4 text-red-600 accent-red-600 focus:outline-none focus:ring-0"
                        disabled={!registeredBrevets.has(brevet.id)}
                        checked={registeredBrevets.get(brevet.id) === true}
                        onchange={(e) =>
                            withMedalChecked(brevet.id, e.target.checked)}
                    />
                    <label for={`medaille-${idx}`} class="text-sm"
                        >Mit Medaille</label
                    >
                </div>

                <div class="flex flex-col gap-1 w-full md:w-auto">
                    <label for={`desired-${idx}`} class="text-sm"
                        >Wunschtermin</label
                    >
                    <input
                        id={`desired-${idx}`}
                        type="date"
                        class="border border-gray-300 rounded-lg px-4 py-3 text-sm disabled:opacity-50"
                        disabled={!registeredBrevets.has(brevet.id)}
                        value={desiredDates.get(brevet.id) || ""}
                        onchange={(e) =>
                            desiredDateChanged(brevet.id, e.target.value)}
                    />
                </div>
            </div>

            {#if isAdmin}
                <div class="flex justify-end pt-4">
                    <button
                        onclick={() => btnEditClicked(brevet.id)}
                        class="bg-black text-white hover:bg-red-700 transition px-6 py-2 rounded-md font-semibold mr-2"
                    >
                        Bearbeiten
                    </button>
                    <button
                        onclick={() => setDelete(brevet.id)}
                        class="bg-black text-white hover:bg-red-700 transition px-6 py-2 rounded-md font-semibold"
                    >
                        Löschen
                    </button>
                </div>

                {#if editingBrevetId === brevet.id}
                      <div class="pt-4">
                          <EditBrevet
                              brevetId={brevet.id}
                              on:close={() => {
                                  editingBrevetId = null;
                                  loadBrevets(currentYear);
                              }}
                          />
                      </div>
                  {/if}

                {#if deletingBrevetId === brevet.id}
                    <div
                        class="mt-3 p-3 bg-red-50 border border-red-200 rounded-md flex items-center justify-between"
                    >
                        <p class="text-red-700 text-sm">
                            Möchten Sie dieses Brevet wirklich löschen?
                        </p>
                        <div class="flex gap-2">
                            <button
                                onclick={() => setDelete(null)}
                                class="px-3 py-1 text-sm bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition ease-in-out duration-150"
                            >
                                Nein
                            </button>
                            <button
                                onclick={() => btnDeleteClicked(brevet.id)}
                                class="px-3 py-1 text-sm bg-red-600 text-white rounded-md hover:bg-red-700 transition ease-in-out duration-150"
                            >
                                Ja
                            </button>
                        </div>
                    </div>
                {/if}
            {/if}
        </div>
    {/each}
</div>

{#if info}
    <p class="text-red-600 text-sm text-center mt-4">{info}</p>
{/if}

<div class="flex justify-between items-center mt-8 max-w-2xl mx-auto">
    <button
        class="bg-black text-white px-6 py-2 rounded-md hover:bg-gray-800"
        onclick={btnRegisterClicked}
        disabled={isButtonDisabled}
    >
        Senden
    </button>

    {#if isAdmin}
        <a href="/brevets/new" class="text-sm underline hover:text-blue-600">
            Neues Brevet anlegen
        </a>
    {/if}
</div>
