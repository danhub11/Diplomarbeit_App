<script>
	import { onMount } from "svelte";
	import { accountId } from "$lib/share-store";

	let info = $state();
	let brevets = $state([]);
	let isLoading = $state(true);

	let isDeletingId = $state(null);
	let validSignOut = $state(true);

	function isFutureBrevet(dateStr) {
		return new Date() <= new Date(dateStr);
	}

	function setIsDeleting(brevetId, brevetDate) {
		isDeletingId = brevetId;
		let now = new Date();
		let brevet = new Date(brevetDate);
		validSignOut = now <= brevet;
	}

	async function loadBrevets() {
		const token = localStorage.getItem("token");
		if (!token) return;

		try {
			const response = await fetch(
				`http://localhost:5000/Brevets/User?accountID=${$accountId}`,
				{
					headers: {
						Authorization: `Bearer ${token}`
					}
				}
			);
			if (!response.ok) throw new Error(await response.text());
			brevets = await response.json();
			console.log(brevets);
		} catch (err) {
			info = err.message;
			console.log(err);
		}
	}

	async function loadAccountAfterRefresh() {
		const token = localStorage.getItem("token");
		if (!token) return;

		try {
			const payload = JSON.parse(atob(token.split(".")[1]));
			accountId.set(Number(payload.sub));
			await loadBrevets();
		} catch (err) {
			console.log("Token ungültig oder abgelaufen", err);
			localStorage.removeItem("token");
			accountId.set(null);
		}
	}

	async function signOutFromBrevet(brevetId) {
		const token = localStorage.getItem("token");
		if (!token) return;

		const payload = {
			brevetId: brevetId,
			accountId: $accountId,
		};

		try {
			const response = await fetch(
				`http://localhost:5000/Brevets/${brevetId}/SignOut?accountId=${$accountId}`,
				{
					method: "PUT",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${token}`
					},
					body: JSON.stringify(payload),
				}
			);
			if (!response.ok) {
				const err = await response.text();
				throw new Error(err);
			}
			const responseText = await response.text();
			info = responseText;

			const index = brevets.findIndex((b) => b.id === brevetId);
			if (index !== -1) {
				brevets[index].participantStatus = "DNS";
			}

			isDeletingId = null;
			setTimeout(() => {
				info = "";
			}, 3000);
		} catch (err) {
			console.log(err);
		}
	}

	onMount(async () => {
		await loadAccountAfterRefresh();
		isLoading = false;
	});
</script>

<div class="min-h-screen bg-white text-black px-4 py-10">
	<div class="max-w-5xl mx-auto">
		<h1 class="text-3xl font-bold border-b-4 border-red-600 pb-2 mb-6">
			Meine Brevets
		</h1>

		{#if isLoading}
			<p class="text-gray-600">Lade Daten ...</p>
		{:else if !$accountId}
			<p class="text-red-600">Bitte zuerst einloggen!</p>
		{:else if brevets.length > 0}
			<div class="space-y-4">
				{#each brevets as brevet}
					<div class="block hover:bg-red-50 transition">
						<div class="bg-gray-100 border-l-4 border-red-600 p-4 rounded-md shadow">
							<div class="flex justify-between items-start">
								<a href={`/lists/${brevet.date}`}>
									<div>
										<p class="font-medium">Brevet {brevet.distance} km</p>
										<p class="text-sm text-gray-700">Datum: {brevet.date.split("T")[0]}</p>
										<p class="text-sm text-gray-700">Ort: {brevet.town}</p>
									</div>
								</a>
								<div class="text-right flex flex-col items-end ml-4 space-y-1">
									{#if brevet.participantStatus === "PENDING"}
										<p class="text-sm text-gray-600 font-semibold">ausständig</p>
										{#if isDeletingId !== brevet.id && isFutureBrevet(brevet.date)}
											<button
												class="mt-1 bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 text-sm"
												onclick={() => setIsDeleting(brevet.id, brevet.date)}
											>
												Abmelden
											</button>
										{/if}
									{:else if brevet.participantStatus === "DNS"}
										<p class="text-sm text-red-600 font-semibold">Abgemeldet / DNS</p>
									{:else if brevet.participantStatus === "DNF"}
										<p class="text-sm text-red-600 font-semibold">DNF</p>
									{:else if brevet.participantStatus === "FINISHED"}
										<p class="text-sm text-green-600 font-semibold">abgeschlossen</p>
									{/if}
								</div>
							</div>

							{#if isDeletingId === brevet.id}
								<div class="mt-4 bg-red-50 border border-red-200 rounded p-3 text-sm">
									{#if validSignOut}
										<p class="mb-2 text-gray-700">
											Sind Sie sicher? DNS wird automatisch eingetragen (siehe Starter-/Finisherliste).
										</p>
										<div class="flex gap-2">
											<button
												class="px-4 py-1 bg-gray-200 rounded hover:bg-gray-300"
												onclick={() => setIsDeleting(null)}
											>
												Nein
											</button>
											<button
												class="px-4 py-1 bg-red-600 text-white rounded hover:bg-red-700"
												onclick={() => signOutFromBrevet(brevet.id)}
											>
												Ja
											</button>
										</div>
									{:else}
										<p class="text-red-600 font-medium">
											Dieses Brevet wurde bereits abgeschlossen – eine Abmeldung ist nicht mehr möglich.
										</p>
									{/if}
								</div>
							{/if}
						</div>
					</div>
				{/each}
			</div>
		{:else}
			<p class="text-gray-600">Sie sind noch bei keinen Brevets angemeldet!</p>
		{/if}

		{#if info}
			<p class="mt-4 text-red-600 text-sm">{info}</p>
		{/if}
	</div>
</div>