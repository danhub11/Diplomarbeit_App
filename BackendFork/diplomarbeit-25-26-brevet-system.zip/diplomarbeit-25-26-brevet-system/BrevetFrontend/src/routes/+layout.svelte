<script>
    import { onMount } from "svelte";
    import { accountId } from "$lib/share-store";

    let { children } = $props();

    let burgerMenuRef = $state();
    let profileMenuRef = $state();

    let isBurgerMenuOpen = $state(false);
    let isProfileMenuOpen = $state(false);
    let isAdmin = $state(false);
    let isLoggedIn = $state(false);

    function toggleBurgerMenu() {
        isBurgerMenuOpen = !isBurgerMenuOpen;
    }

    function toggleProfileMenu() {
        isProfileMenuOpen = !isProfileMenuOpen;
    }

    function handleClickOutside(event) {
        const clickedBurger =
            burgerMenuRef?.contains(event.target) ||
            event.target.closest("[data-burger-button]");
        const clickedProfile =
            profileMenuRef?.contains(event.target) ||
            event.target.closest("[data-profile-button]");

        if (isBurgerMenuOpen && !clickedBurger) isBurgerMenuOpen = false;
        if (isProfileMenuOpen && !clickedProfile) isProfileMenuOpen = false;
    }

    async function loadAccountAfterRefresh() {
        const token = localStorage.getItem("token");
        if(!token) return;
        try {
            const payload = JSON.parse(atob(token.split(".")[1]));
            accountId.set(Number(payload.sub)); // => sub = user id
        } catch (err) {
            console.log("Token ist abgelaufen oder ungültig", err);
            loadStorage.removeItem("token");
            accountId.set(null);
        }
    }

    async function checkIsAdmin() {
        const token = localStorage.getItem("token");
        if(!token) return;
        try {
            const reponse = await fetch(
                `http://localhost:5000/Accounts/IsAdmin`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );
            if (!reponse.ok) throw new Error(await reponse.text());
            isAdmin = await reponse.json();
        } catch (err) {
            console.log(err);
        }
    }

    onMount(() => {
        loadAccountAfterRefresh();

        const unsubscribe = accountId.subscribe(async (id) => {
            isLoggedIn = id !== null;
            if (id) await checkIsAdmin();
        });

        window.addEventListener("click", handleClickOutside);
        return () => {
            unsubscribe();
            window.removeEventListener("click", handleClickOutside);
        };
    });
</script>

<div class="min-h-screen bg-white font-sans antialiased">
    <header class="bg-red-700 text-white p-4 shadow-md">
        <div class="container mx-auto flex items-center justify-between">
            <!-- Burger-Menü -->
            <div class="relative w-48 flex-shrink-0">
                <button
                    data-burger-button
                    onclick={toggleBurgerMenu}
                    class="text-white focus:outline-none p-2 rounded-md hover:bg-red-600 transition-colors"
                    aria-label="Menü öffnen"
                >
                    <svg
                        class="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16"
                        />
                    </svg>
                </button>

                {#if isBurgerMenuOpen}
                    <nav
                        bind:this={burgerMenuRef}
                        class="absolute left-0 mt-2 w-48 bg-red-800 rounded-md shadow-lg z-20"
                    >
                        <a href="/brevets/current" class="block px-4 py-2 text-sm text-white hover:bg-red-600">Brevets</a>
                        <a href="/lists/overview" class="block px-4 py-2 text-sm text-white hover:bg-red-600">Starterlisten</a>
                        <a href="/impressum" class="block px-4 py-2 text-sm text-white hover:bg-red-600">Impressum</a>

                        <!-- Statistiken Dropdown -->
                        <div class="group relative">
                            <div
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600 cursor-pointer"
                            >
                                Statistiken
                            </div>
                            <div
                                class="absolute left-full top-0 mt-0 hidden group-hover:block bg-red-700 shadow-md rounded-md z-30"
                            >
                                <a
                                    href="/statistics/finisher"
                                    class="block px-4 py-2 text-sm text-white hover:bg-red-600 whitespace-nowrap"
                                    >Finisher</a
                                >
                                <a
                                    href="/statistics/starter/country"
                                    class="block px-4 py-2 text-sm text-white hover:bg-red-600 whitespace-nowrap"
                                    >Starter nach Land</a
                                >
                                <a
                                    href="/statistics/year"
                                    class="block px-4 py-2 text-sm text-white hover:bg-red-600 whitespace-nowrap"
                                    >Jahresstatistik</a
                                >
                            </div>
                        </div>

                        {#if isAdmin}
                            <a
                                href="/randonneurs"
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600"
                                >Randonneurs</a
                            >
                            <a
                                href="/settings"
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600"
                                >Einstellungen</a
                            >
                        {/if}
                    </nav>
                {/if}
            </div>

            <!-- Titel -->
            <h1
                class="text-2xl sm:text-3xl font-bold text-white mb-2 text-center"
            >
                <a href="/" class="no-underline hover:no-underline"
                    >Randonneurs Austria</a
                >
            </h1>

            <!-- Profil-Menü -->
            <div class="relative w-48 flex-shrink-0 flex justify-end">
                <button
                    data-profile-button
                    onclick={toggleProfileMenu}
                    class="text-white font-bold flex items-center gap-1 hover:opacity-80 transition-opacity"
                >
                    <svg
                        class="w-5 h-5"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                    >
                        <path
                            fill-rule="evenodd"
                            d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                            clip-rule="evenodd"
                        />
                    </svg>
                    Konto
                </button>
                {#if isProfileMenuOpen}
                    <nav
                        bind:this={profileMenuRef}
                        class="absolute right-0 mt-2 w-48 bg-red-800 rounded-md shadow-lg z-20"
                    >
                        {#if !isLoggedIn}
                            <a
                                href="/login"
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600"
                                >Anmelden</a
                            >
                            <a
                                href="/register"
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600"
                                >Konto erstellen</a
                            >
                        {:else}
                            <a
                                href={`/accounts/data/${$accountId}`}
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600"
                                >Profil</a
                            >
                            <a
                                href={`/brevets/user/${$accountId}`}
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600"
                                >Meine Fahrten</a
                            >
                            <a
                                href="/"
                                onclick={() => {
                                    accountId.set(null);
                                    localStorage.removeItem("token");
                                    location.reload();
                                }}
                                class="block px-4 py-2 text-sm text-white hover:bg-red-600 flex justify-between items-center"
                            >
                                <span>Abmelden</span>
                                <img
                                    src="/Logout.png"
                                    alt="Logout"
                                    class="w-5 h-5 ml-2"
                                />
                            </a>
                        {/if}
                    </nav>
                {/if}
            </div>
        </div>
    </header>

    {@render children()}

    <footer class="bg-red-700 text-white p-4 mt-8 text-center">
        <div class="container mx-auto">
            <p>&copy; 2025 Audax Randonneurs Autriche</p>
        </div>
    </footer>
</div>

<style global>
    @import "../app.css";
</style>
