<script>
	import { goto } from '$app/navigation';

	function goToBrevets() {
		goto('/register');
	}
</script>

<main class="container mx-auto px-6 sm:px-10 py-16 flex flex-col items-center justify-center text-center text-black">

	<!-- Hero Section -->
	<section class="w-full max-w-5xl">
		<h1 class="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight leading-tight mb-6">
			Willkommen bei
			<span class="text-red-700">Randonneurs Austria</span>
		</h1>

		<p class="text-lg sm:text-xl text-gray-700 mb-10 max-w-3xl mx-auto">
			Entdecke die Welt der Langstreckenfahrten. Brevets, Abenteuer und Ausdauer – bei jedem Wetter, mit jedem Ziel.
		</p>

		<button
			onclick={goToBrevets}
			class="bg-red-700 text-white px-8 py-3 rounded-full text-lg font-semibold shadow-md
			hover:bg-black hover:scale-105 transition duration-300"
		>
			Jetzt loslegen →
		</button>
	</section>

	<!-- Hero Image -->
	<div
		class="w-full max-w-5xl mt-16 rounded-2xl overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-500 ease-in-out"
	>
		<img
			src="/AudaxRandonneursAutriche.jpg"
			alt="Eine Gruppe Rennradfahrer auf einer malerischen Straße"
			class="w-full h-auto object-cover"
		/>
	</div>

	<!-- Werte-Sektion -->
	<section class="mt-20 max-w-4xl space-y-12 text-left">
		<div class="flex flex-col sm:flex-row items-start gap-6">
			<div class="flex-shrink-0 w-14 h-14 bg-red-700 text-white rounded-full flex items-center justify-center text-2xl font-bold">
				1
			</div>
			<div>
				<h2 class="text-xl font-bold text-gray-900">Ausdauer & Abenteuer</h2>
				<p class="text-gray-700">
					Unsere Brevets fordern Körper und Geist – ob 200 oder 1.000 km. Entdecke deine Grenzen neu.
				</p>
			</div>
		</div>

		<div class="flex flex-col sm:flex-row items-start gap-6">
			<div class="flex-shrink-0 w-14 h-14 bg-red-700 text-white rounded-full flex items-center justify-center text-2xl font-bold">
				2
			</div>
			<div>
				<h2 class="text-xl font-bold text-gray-900">Gemeinschaft & Freiheit</h2>
				<p class="text-gray-700">
					Ob alleine oder im Team – jeder fährt für sich, aber nie wirklich allein. Randonneurs teilen Leidenschaft.
				</p>
			</div>
		</div>

		<div class="flex flex-col sm:flex-row items-start gap-6">
			<div class="flex-shrink-0 w-14 h-14 bg-red-700 text-white rounded-full flex items-center justify-center text-2xl font-bold">
				3
			</div>
			<div>
				<h2 class="text-xl font-bold text-gray-900">Verlässlichkeit & Herzblut</h2>
				<p class="text-gray-700">
					Von der Anmeldung bis zur Medaille: Wir leben Organisation, Fairness und Begeisterung für den Sport.
				</p>
			</div>
		</div>
	</section>
</main>
