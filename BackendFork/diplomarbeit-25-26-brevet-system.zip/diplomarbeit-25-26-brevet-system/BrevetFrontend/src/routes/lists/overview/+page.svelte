<script>
    import StartslistOverview from "$lib/components/StartslistOverview.svelte";
    import { onMount } from "svelte";
    import { accountId } from "$lib/share-store";

    const currentYear = new Date().getFullYear();
    const startYear = 1994;
    const endYear = currentYear + 1;

    const years = Array.from(
        { length: endYear - startYear + 1 },
        (_, i) => startYear + i,
    );

    let year = $state(currentYear);
    let brevets = $state([]);
    let isLoading = $state(false);
    let error = $state(null);
    let open = $state(false);

    let dropdownRef;

    let visibilitySetting = $state();
    

    async function loadSettings() {
        try {
            const response = await fetch("http://localhost:5000/Settings/Get");
            if (!response.ok) {
                const err = await response.text();
                throw new Error(err);
            }
            let responseBody = await response.json();
            visibilitySetting = responseBody.setting;
        } catch (err) {
            console.log(err);
        }
    }

    async function loadBrevets() {
        isLoading = true;
        error = null;
        brevets = [];
        let url;

        if (visibilitySetting === "nur für Teilnehmer des Brevets") {
            if ($accountId) {
                url = `http://localhost:5000/Brevets?year=${year}&accountId=${$accountId}&visibilitySettings=${visibilitySetting}`;
            } else {
                isLoading = false;
                return;
            }
        } else if (visibilitySetting === "nur für eingeloggte User") {
            if ($accountId) {
                url = `http://localhost:5000/Brevets?year=${year}`;
            } else {
                isLoading = false;
                return;
            }
        } else {
            url = `http://localhost:5000/Brevets?year=${year}`;
        }

        try {
            const response = await fetch(url);
            if (!response.ok) {
                const errText = await response.text();
                error = `Fehler beim Laden der Brevets: ${errText || response.statusText}`;
                throw new Error(errText);
            }
            brevets = await response.json();
        } catch (err) {
            console.error(err);
            if (!error) {
                error =
                    "Es gab ein Problem beim Abrufen der Daten. Bitte versuchen Sie es später erneut.";
            }
        } finally {
            isLoading = false;
        }
    }

    function toggleDropdown() {
        open = !open;
    }

    function choose(y) {
        year = y;
        open = false;
        loadBrevets();
    }

    onMount(async () => {
        await loadSettings();
        await loadBrevets();
        const handleClickOutside = (event) => {
            if (open && dropdownRef && !dropdownRef.contains(event.target)) {
                open = false;
            }
        };

        window.addEventListener("click", handleClickOutside);

        return () => {
            window.removeEventListener("click", handleClickOutside);
        };
    });
</script>

<div class="max-w-6xl mx-auto my-10 p-8 bg-card rounded-xl shadow-light">
    <h1 class="text-primary text-center text-4xl font-bold mb-8">
        Starterlisten
    </h1>

    <div class="flex items-center justify-center gap-4 mb-10">
        <label for="year-dropdown" class="text-lg font-semibold text-text-color"
            >Jahr auswählen:</label
        >

        <div class="relative w-40" bind:this={dropdownRef}>
            <button
                id="year-dropdown"
                onclick={toggleDropdown}
                class="w-full px-4 py-2 border-2 rounded-lg text-left
				       border-red-700 bg-white text-black font-medium
				       focus:outline-none focus:ring-1 focus:ring-red-700"
            >
                {year}
                <svg
                    class="w-4 h-4 inline float-right"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    viewBox="0 0 24 24"
                >
                    <path
                        d="M19 9l-7 7-7-7"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                    />
                </svg>
            </button>

            {#if open}
                <ul
                    class="absolute z-10 mt-1 w-full bg-white border border-red-700 rounded-lg max-h-60 overflow-auto shadow-lg"
                >
                    {#each years as y}
                        <li>
                            <button
                                type="button"
                                onclick={() => choose(y)}
                                class="w-full text-left px-4 py-2 text-sm cursor-pointer transition-colors
		                            hover:bg-red-100
		                        {year === y
                                    ? 'bg-red-700 text-white font-semibold'
                                    : ''}"
                            >
                                {y}
                            </button>
                        </li>
                    {/each}
                </ul>
            {/if}
        </div>
    </div>

    {#if isLoading}
        <div
            class="text-center p-8 mt-8 rounded-lg bg-info-bg text-info border border-blue-200"
        >
            <div
                class="spinner w-10 h-10 border-4 border-info/20 border-t-info rounded-full animate-spin mx-auto mb-4"
            ></div>
            <p>Daten werden geladen...</p>
        </div>
    {:else if error}
        <div
            class="text-center p-8 mt-8 rounded-lg bg-error-bg text-error border border-red-300"
        >
            <p>{error}</p>
            <p class="mt-2">
                Bitte versuchen Sie, die Seite neu zu laden oder wählen Sie ein
                anderes Jahr.
            </p>
        </div>
    {:else if brevets.length === 0}
        {#if visibilitySetting === "nur für eingeloggte User" && !$accountId}
            <div
                class="text-center p-8 mt-8 rounded-lg bg-warning-bg text-warning border border-orange-200"
            >
                <p>
                    Bitte loggen Sie sich ein, um die Brevets sehen zu können.
                </p>
            </div>
        {:else if visibilitySetting === "nur für Teilnehmer des Brevets" && !$accountId}
            <div
                class="text-center p-8 mt-8 rounded-lg bg-warning-bg text-warning border border-orange-200"
            >
                <p>Bitte loggen Sie sich ein, um Ihre Brevets zu sehen.</p>
            </div>
        {:else if visibilitySetting === "nur für Teilnehmer des Brevets"}
            <div
                class="text-center p-8 mt-8 rounded-lg bg-warning-bg text-warning border border-orange-200"
            >
                <p>Sie nehmen im Jahr {year} an keinen Brevets teil.</p>
            </div>
        {:else}
            <div
                class="text-center p-8 mt-8 rounded-lg bg-warning-bg text-warning border border-orange-200"
            >
                <p>Für das Jahr {year} wurden keine Brevets gefunden.</p>
            </div>
        {/if}
    {:else if visibilitySetting}
        <StartslistOverview {brevets} {visibilitySetting} />
    {/if}
</div>

<style>
    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    .animate-spin {
        animation: spin 1s linear infinite;
    }
</style>
