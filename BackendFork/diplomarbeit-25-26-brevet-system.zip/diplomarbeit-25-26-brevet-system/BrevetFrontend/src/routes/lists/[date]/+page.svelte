<script>
    import { onMount } from "svelte";
    import { accountId } from "$lib/share-store.js";
    const { data } = $props();

    let starterList = $state([]);
    let fullStarterList = $state([]);
    let brevetInformation = $state();
    let brevetId = $state();
    let dataLoaded = $state(false);
    let search = $state();
    let isAdmin = $state(false);
    let isEditing = $state(false);
    const status = ["DNS", "DNF", "FINISHED", "PENDING"];
    async function loadBrevet() {
        try {
            const reponse = await fetch(
                `http://localhost:5000/StarterList/${data.date}`,
            );
            if (!reponse.ok) {
                const err = await reponse.text();
                throw new Error(err);
            }
            let responseBody = await reponse.json();
            starterList = [...responseBody];
            fullStarterList = [...responseBody];
            brevetId = starterList[0].brevetId;
        } catch (err) {
            console.log(err);
        }
    }

    async function loadBrevetInformation() {
        try {
            const reponse = await fetch(
                `http://localhost:5000/Brevets/Id?brevetId=${brevetId}`,
            );
            if (!reponse.ok) {
                const err = await reponse.text();
                throw new Error(err);
            }
            let responseBody = await reponse.json();
            brevetInformation = responseBody;
            dataLoaded = true;
        } catch (err) {
            console.log(err);
        }
    }

    async function checkIsAdmin() {
        const token = localStorage.getItem("token");
        if(!token) return;
        try {
            const reponse = await fetch(
                `http://localhost:5000/Accounts/IsAdmin`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );
            if (!reponse.ok) throw new Error(await reponse.text());
            isAdmin = await reponse.json();
        } catch (err) {
            console.log(err);
        }
    }

    function filterStarter() {
        if (!search) {
            starterList = [...fullStarterList];
        } else {
            const q = search.trim().toLowerCase();
            starterList = fullStarterList.filter(
                (x) =>
                    (x.lastname || "").toLowerCase().includes(q) ||
                    (x.firstname || "").toLowerCase().includes(q) ||
                    (x.location || "").toLowerCase().includes(q) ||
                    (x.country || "").toLowerCase().includes(q) ||
                    (x.withMedal || "").toString().toLowerCase().includes(q) ||
                    (x.paid || "").toString().toLowerCase().includes(q) ||
                    (x.status || "").toLowerCase().includes(q) ||
                    (x.homologationNr || "").toString().includes(q),
            );
        }
    }

    function editParticipant() {
        isEditing = isEditing ? false : true;
    }

    async function paidChecked(id, isChecked) {
        const payload = {
            participantId: id,
            isPaid: isChecked,
        };

        try {
            const response = await fetch(
                `http://localhost:5000/IsPaid?participantId=${id}&isPaid=${isChecked}`,
                {
                    method: "PUT",
                    headers: { "Content-Type": "application.json" },
                    body: JSON.stringify(payload),
                },
            );
            if (!response.ok) {
                const err = await response.text();
                throw new Error(err);
            }
        } catch (err) {
            console.log(err);
        }
    }

    async function updateStatus(participantId, status) {
        const payload = {
            participantId: participantId,
            status: status,
        };

        try {
            const response = await fetch(
                `http://localhost:5000/Status?ParticipantId=${participantId}&Status=${status}`,
                {
                    method: "PUT",
                    headers: { "Content-Type": "application.json" },
                    body: JSON.stringify(payload),
                },
            );
            if (!response.ok) {
                const err = await response.text();
                throw new Error(err);
            }
        } catch (err) {
            console.log(err);
        }
    }

    function doneBtnClicked() {
        isEditing = false;
        loadBrevet();
    }

    onMount(async () => {
        checkIsAdmin();
        await loadBrevet();
        loadBrevetInformation();
    });
</script>

<div class="min-h-screen bg-white text-black px-6 py-10">
    <div class="max-w-6xl mx-auto space-y-8">
        {#if dataLoaded}
            <div class="space-y-1">
                <h1 class="text-2xl font-bold text-red-700">
                    {brevetInformation.distance} km Brevet am {brevetInformation.date.split(
                        "T",
                    )[0]}
                </h1>
                <p class="text-gray-700 font-medium">
                    Ort: {brevetInformation.town} – Audax Randonneurs Autriche
                </p>
            </div>

            <div class="mt-6">
                <input
                    type="text"
                    bind:value={search}
                    placeholder="Teilnehmer suchen..."
                    class="w-full sm:w-1/2 border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                    oninput={filterStarter}
                />
            </div>

            {#if isAdmin == true}
                <button onclick={editParticipant}>Bearbeiten</button>
            {/if}
            {#if isEditing == true}
                <button onclick={doneBtnClicked}>Fertig</button>
            {/if}

            <div
                class="overflow-x-auto mt-6 rounded-lg shadow border border-gray-300"
            >
                <table class="min-w-full table-auto text-sm text-left">
                    <thead class="bg-red-600 text-white">
                        <tr>
                            <th class="px-4 py-2">Bild</th>
                            <th class="px-4 py-2">Nachname</th>
                            <th class="px-4 py-2">Vorname</th>
                            <th class="px-4 py-2">Ort</th>
                            <th class="px-4 py-2">Land</th>
                            <th class="px-4 py-2">Med.</th>
                            <th class="px-4 py-2">Bez.</th>
                            <th class="px-4 py-2">Status</th>
                            <th class="px-4 py-2">Homologation</th>
                        </tr>
                    </thead>
                    <tbody>
                        {#each starterList as starter}
                            <tr class="border-t">
                                <td class="px-2 py-2">
                                    <img
                                        src={starter.profileImagePath
                                            ? `http://localhost:5000${starter.profileImagePath}?t=${Date.now()}`
                                            : "/Profil.png"}
                                        alt="Profilbild"
                                        class="w-10 h-10 rounded-full object-cover border border-gray-300"
                                    />
                                </td>
                                <td class="px-4 py-2">{starter.lastname}</td>
                                <td class="px-4 py-2">{starter.firstname}</td>
                                <td class="px-4 py-2">{starter.location}</td>
                                <td class="px-4 py-2">{starter.country}</td>
                                <td class="px-4 py-2 text-center"
                                    >{starter.withMedal ? "✓" : ""}</td
                                >

                                {#if isEditing == true}
                                    <td>
                                        <input
                                            type="checkbox"
                                            onchange={(e) =>
                                                paidChecked(
                                                    starter.id,
                                                    e.target.checked,
                                                )}
                                            checked={starter.paid}
                                        />
                                    </td>
                                {:else}
                                    <td class="px-4 py-2 text-center"
                                        >{starter.paid ? "✓" : ""}</td
                                    >
                                {/if}

                                {#if isEditing == true}
                                    <td>
                                        <select
                                            bind:value={starter.status}
                                            onchange={(e) =>
                                                updateStatus(
                                                    starter.id,
                                                    e.target.value,
                                                )}
                                        >
                                            {#each status as s}
                                                <option value={s}>{s}</option>
                                            {/each}
                                        </select>
                                    </td>
                                {:else}
                                    <td class="px-4 py-2">{starter.status}</td>
                                {/if}

                                <td class="px-4 py-2"
                                    >{starter.homologationNr}</td
                                >
                            </tr>
                        {/each}
                    </tbody>
                </table>
            </div>
        {:else}
            <p class="text-gray-500">Lade Daten ...</p>
        {/if}
    </div>
</div>
