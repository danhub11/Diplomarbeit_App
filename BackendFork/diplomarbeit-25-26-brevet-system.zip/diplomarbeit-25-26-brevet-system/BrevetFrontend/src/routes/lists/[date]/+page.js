import { error } from '@sveltejs/kit';

export function load({ params }) {
    const date = params.date;
    if (date) {
        return {
            date: date
        };
    };
    return error(404, `No data found for date ${date}`);
}