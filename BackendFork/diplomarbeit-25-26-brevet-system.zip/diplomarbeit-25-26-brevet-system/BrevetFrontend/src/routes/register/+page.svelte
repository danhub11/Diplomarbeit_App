<script>
	let firstname = $state();
	let lastname = $state();
	let dateOfBirth = $state();
	let address = $state();
	let plz = $state();
	let city = $state();
	let country = $state();
	let email = $state();
	let phoneNumber = $state();
	let password = $state();
	let repeatPasswort = $state();
	let info = $state();

	async function registerClicked() {
		if (
			firstname && lastname && dateOfBirth && plz && city &&
			country && email && phoneNumber
		) {
			if (password !== repeatPasswort) {
				info = "Passwörter stimmen nicht überein!";
			} else {
				info = "";
				const payload = {
					PasswordHash: password,
					RepeatPassword: repeatPasswort,
					Randonneur: {
						Firstname: firstname,
						Lastname: lastname,
						Address: address,
						PLZ: plz,
						City: city,
						Country: country,
						Email: email,
						PhoneNumber: phoneNumber,
						DateOfBirth: dateOfBirth,
					},
				};

				try {
					const response = await fetch("http://localhost:5000/Accounts/Register", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify(payload)
					});
					if (response.ok) {
						alert("Registrierung erfolgreich!");
						location.href = "/login";
					} else {
						const error = await response.text();
						info = "Fehler bei der Registrierung: " + error;
					}
				} catch (err) {
					info = "Server nicht erreichbar!";
				}
			}
		} else {
			info = "Bitte füllen Sie alle erforderlichen Felder aus!";
		}
	}
</script>

<div class="max-w-4xl mx-auto p-4 overflow-auto text-sm">
	<h1 class="text-xl font-semibold mb-4 text-center">Account erstellen</h1>

	<div class="grid grid-cols-1 md:grid-cols-2 gap-3">
		<!-- Erste Zeile -->
		<div>
			<label for="firstname" class="block font-medium mb-1">Vorname</label>
			<input id="firstname" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="text" bind:value={firstname} />
		</div>

		<div>
			<label for="plz" class="block font-medium mb-1">PLZ</label>
			<input id="plz" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="number" bind:value={plz} />
		</div>

		<!-- Zweite Zeile -->
		<div>
			<label for="lastname" class="block font-medium mb-1">Nachname</label>
			<input id="lastname" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="text" bind:value={lastname} />
		</div>

		<div>
			<label for="address" class="block font-medium mb-1">Adresse</label>
			<input id="address" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="text" bind:value={address} />
		</div>

		<!-- Dritte Zeile -->
		<div>
			<label for="email" class="block font-medium mb-1">E-Mail</label>
			<input id="email" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="email" bind:value={email} />
		</div>

		<div>
			<label for="city" class="block font-medium mb-1">Stadt</label>
			<input id="city" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="text" bind:value={city} />
		</div>

		<!-- Vierte Zeile -->
		<div>
			<label for="phoneNumber" class="block font-medium mb-1">Telefon</label>
			<input id="phoneNumber" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="tel" bind:value={phoneNumber} />
		</div>

		<div>
			<label for="country" class="block font-medium mb-1">Bundesland</label>
			<input id="country" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="text" bind:value={country} />
		</div>

		<!-- Fünfte Zeile -->
		<div>
			<label for="password" class="block font-medium mb-1">Passwort</label>
			<input id="password" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="password" bind:value={password} />
		</div>

		<div>
			<label for="dateOfBirth" class="block font-medium mb-1">Geburtsdatum</label>
			<input id="dateOfBirth" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="date" bind:value={dateOfBirth} />
		</div>

		<!-- Sechste Zeile -->
		<div>
			<label for="repeatPasswort" class="block font-medium mb-1">Passwort wiederholen</label>
			<input id="repeatPasswort" class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700" type="password" bind:value={repeatPasswort} />
		</div>
	</div>

	<button
		class="w-full bg-black text-white py-1.5 mt-6 text-sm hover:bg-gray-800 rounded-lg"
		onclick={registerClicked}
	>
		Erstellen
	</button>

	<p class="text-red-600 mt-2">{info}</p>

	<div class="mt-4 text-xs text-center">
		Sie haben schon einen Account? <a href="/login" class="underline">Einloggen</a>
	</div>
</div>
