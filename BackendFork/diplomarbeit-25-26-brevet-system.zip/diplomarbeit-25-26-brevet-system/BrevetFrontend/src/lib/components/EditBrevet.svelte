<script>
	import { onMount, onDestroy, createEventDispatcher } from "svelte";
	let { brevetId } = $props();
	const dispatch = createEventDispatcher();

	let distance = $state();
	let date = $state();
	let town = $state();
	let status = $state("offen");
	let info = $state();

	let statusOpen = $state(false);
	let statusOptions = ["abgeschlossen", "offen"];

	let dropdownRef; // Referenz fürs Status-Dropdown

	function toggleStatusDropdown() {
		statusOpen = !statusOpen;
	}

	function selectStatus(value) {
		status = value;
		statusOpen = false;
	}

	async function loadBrevetInformation() {
		try {
			const response = await fetch(
				`http://localhost:5000/Brevets/Id?brevetId=${brevetId}`,
			);
			if (!response.ok) throw new Error(await response.text());
			const data = await response.json();
			distance = data.distance;
			date = data.date;
			town = data.town;
			status = data.status || "offen";
		} catch (err) {
			console.log(err);
		}
	}

	async function btnSaveClicked() {
		if (distance < 200) {
			info = "Die Distanz muss mindestens 200 km betragen!";
			return;
		}

		const payload = {
			Id: brevetId,
			Distance: distance || null,
			Date: date || null,
			Town: town || null,
			Status: status || null,
		};

		const params = new URLSearchParams();
		params.append("id", brevetId);
		if (distance) params.append("distance", distance);
		if (date) params.append("date", date);
		if (town) params.append("town", town);
		if (status) params.append("status", status);

		try {
			const response = await fetch(
				`http://localhost:5000/Brevets?${params.toString()}`,
				{
					method: "PUT",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(payload),
				},
			);
			if (!response.ok) throw new Error(await response.text());

			info = "Brevet erfolgreich geändert!";
			setTimeout(() => {
				dispatch("close", {});
			}, 1500);
		} catch (err) {
			console.log(err);
		}
	}

	onMount(() => {
		loadBrevetInformation();

		function handleClickOutside(event) {
			if (
				statusOpen &&
				dropdownRef &&
				!dropdownRef.contains(event.target)
			) {
				statusOpen = false;
			}
		}

		window.addEventListener("click", handleClickOutside);

		return () => {
			window.removeEventListener("click", handleClickOutside);
		};
	});
</script>

<div class="mt-4 space-y-4">
	<div>
		<label
			for="distance"
			class="block text-sm font-medium text-gray-700 mb-1"
		>
			Distanz (km)
		</label>
		<input
			type="number"
			bind:value={distance}
			class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700"
		/>
	</div>

	<div>
		<label for="date" class="block text-sm font-medium text-gray-700 mb-1">
			Datum
		</label>
		<input
			type="date"
			bind:value={date}
			class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700"
		/>
	</div>

	<div>
		<label for="town" class="block text-sm font-medium text-gray-700 mb-1">
			Ort
		</label>
		<input
			type="text"
			bind:value={town}
			class="w-full border border-gray-300 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-700"
		/>
	</div>

	<!-- Custom Status Dropdown -->
	<div>
		<label
			for="status"
			class="block text-sm font-medium text-gray-700 mb-1"
		>
			Status
		</label>

		<div class="relative w-full" bind:this={dropdownRef}>
			<button
				type="button"
				onclick={toggleStatusDropdown}
				class="w-full border border-gray-300 rounded-lg p-2 text-sm text-left bg-white
                   focus:outline-none focus:ring-1 focus:ring-red-700 focus:border-red-700"
			>
				{status}
				<span class="float-right">&#x25BC;</span>
			</button>

			{#if statusOpen}
				<ul
					class="absolute z-10 w-full mt-1 bg-white rounded-lg
				max-h-40 overflow-auto text-sm shadow-md"
				>
					{#each statusOptions as s}
						<li>
							<button
								type="button"
								class="w-full text-left px-4 py-2 hover:bg-red-100 hover:text-black cursor-pointer"
								onclick={() => selectStatus(s)}
							>
								{s}
							</button>
						</li>
					{/each}
				</ul>
			{/if}
		</div>
	</div>

	<div class="flex justify-end items-center">
		{#if info}
			<p class="text-sm text-red-600 mr-auto">{info}</p>
		{/if}
		<button
			class="bg-black text-white hover:bg-red-700 transition px-6 py-2 rounded-md font-semibold"
			onclick={btnSaveClicked}
		>
			Speichern
		</button>
	</div>
</div>
