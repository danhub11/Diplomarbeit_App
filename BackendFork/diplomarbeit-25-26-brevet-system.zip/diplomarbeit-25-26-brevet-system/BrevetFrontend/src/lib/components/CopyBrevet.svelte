<script>
    import { onMount } from "svelte";
    let { selectedBrevets = $bindable([]) } = $props();
    let brevets = $state();
    // let selectedBrevets = $state([]);
    async function loadBrevets() {
        var date = new Date();
        let year = date.getFullYear() - 1;
        try {
            const response = await fetch(
                `http://localhost:5000/Brevets?year=${year}`,
            );
            if (!response.ok) {
                const err = await response.text();
                throw new Error(err);
            }
            let responseBody = await response.json();
            brevets = [...responseBody];
        } catch (err) {
            console.log(err);
        }
    }

    function toggleSelectedBrevet(brevet) {
        if (selectedBrevets.includes(brevet)) {
            selectedBrevets = selectedBrevets.filter((b) => b !== brevet);
        } else {
            selectedBrevets = [...selectedBrevets, brevet];
        }
    }

    onMount(() => {
        loadBrevets();
    });
</script>

<table>
    <tbody>
        {#each brevets as brevet}
            <tr>
                <td>
                    <input
                        type="checkbox"
                        checked={selectedBrevets.includes(brevet)}
                        onchange={() => toggleSelectedBrevet(brevet)}
                    />
                    {brevet.distance} km Brevet, {brevet.date}, {brevet.town}
                </td>
            </tr>
        {/each}
    </tbody>
</table>
