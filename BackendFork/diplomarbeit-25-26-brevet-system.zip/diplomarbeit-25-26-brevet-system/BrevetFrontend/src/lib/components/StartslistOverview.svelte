<script>
	let { brevets = $bindable() } = $props();
</script>

{#if brevets.length > 0}
	<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
		{#each brevets as brevet (brevet.id)}
			<a
				href={`/lists/${brevet.date}`}
				class="bg-white rounded-xl border border-gray-300
					hover:border-red-700 hover:ring-1 hover:ring-red-700
					shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-200 ease-in-out
					p-6 flex flex-col justify-between cursor-pointer group"
			>
				<div>
					<h2 class="text-xl font-bold text-gray-800 group-hover:text-red-700 transition-colors duration-200 mb-3">
						{brevet.name}
					</h2>
					<p class="text-sm text-gray-700 mb-1">
						<strong>Datum:</strong> {new Date(brevet.date).toLocaleDateString("de-DE")}
					</p>
					<p class="text-sm text-gray-700 mb-1">
						<strong>Distanz:</strong> {brevet.distance} km
					</p>
					{#if brevet.town}
						<p class="text-sm text-gray-700 mb-1">
							<strong>Ort:</strong> {brevet.town}
						</p>
					{/if}
				</div>

				{#if brevet.status}
					<div class="mt-4">
						<span
							class={`inline-block px-3 py-1 rounded-full text-sm font-semibold
								${brevet.status.toLowerCase() === "pending" ? "bg-yellow-100 text-yellow-800" : ""}
								${brevet.status.toLowerCase() === "completed" ? "bg-green-100 text-green-800" : ""}
								${brevet.status.toLowerCase() === "cancelled" ? "bg-red-100 text-red-800" : ""}`}
						>
							{brevet.status}
						</span>
					</div>
				{/if}
			</a>
		{/each}
	</div>
{:else}
	<p class="text-center mt-6 italic text-gray-500">Keine Brevets zur Anzeige.</p>
{/if}