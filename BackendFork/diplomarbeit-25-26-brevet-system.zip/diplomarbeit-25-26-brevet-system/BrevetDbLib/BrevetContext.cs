﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrevetDbLib;

public class BrevetContext : DbContext
{
    public BrevetContext() { }
    public BrevetContext(DbContextOptions<BrevetContext> options) : base(options) { }
    public DbSet<Randonneur> Randonneurs { get; set; }
    public DbSet<Brevet> Brevets { get; set; }
    public DbSet<Participant> Participants { get; set; }
    public DbSet<Account> Accounts { get; set; }
    public DbSet<VisibilitySetting> VisibilitySettings { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        Console.WriteLine($"Db OnConfiguring: IsConfigured={optionsBuilder.IsConfigured}");
        if (optionsBuilder.IsConfigured) return;

        string connectionString = @"server=(LocalDB)\mssqllocaldb;attachdbfilename=C:\Database\Brevets.mdf;database=Brevets;integrated security=True;MultipleActiveResultSets=True;";
        //string connectionString = @"server=(LocalDB)\mssqllocaldb;attachdbfilename=D:\PosDb\Diplomarbeit\Brevets.mdf;database=Brevets;integrated security=True;MultipleActiveResultSets=True;";

        Console.WriteLine($"Using connection string: {connectionString}");
        optionsBuilder.UseSqlServer(connectionString);
    }
}