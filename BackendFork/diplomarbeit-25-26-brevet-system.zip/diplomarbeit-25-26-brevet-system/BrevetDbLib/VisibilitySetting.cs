﻿namespace BrevetDbLib;

public class VisibilitySetting
{
    public int Id { get; set; }
    public string Setting { get; set; } = null!;
}
