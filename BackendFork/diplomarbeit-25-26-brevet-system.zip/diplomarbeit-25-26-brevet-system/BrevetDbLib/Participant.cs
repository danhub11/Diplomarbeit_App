﻿namespace BrevetDbLib;

public class Participant
{
    public int Id { get; set; }
    public bool? Paid { get; set; }
    public int? HomologationNr { get; set; }
    public bool? WithMedal { get; set; }
    public string Status { get; set; } = null!;

    public Randonneur Randonneur { get; set; } = null!;
    public Brevet Brevet { get; set; } = null!;
}
