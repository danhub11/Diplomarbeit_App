﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrevetDbLib;
public class Account
{
    public int Id { get; set; }
    public Guid LoginId { get; set; } = Guid.NewGuid();
    public string PasswordHash { get; set; } = null!;
    public bool IsAdmin { get; set; }
    public int RandonneurId { get; set; }
    public bool IsLocked { get; set; } = false;
    public string? ProfileImagePath { get; set; }
    public Randonneur Randonneur { get; set; } = null!; 
}