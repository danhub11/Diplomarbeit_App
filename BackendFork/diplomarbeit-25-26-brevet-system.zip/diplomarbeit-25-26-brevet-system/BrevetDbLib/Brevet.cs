﻿namespace BrevetDbLib;

public class Brevet
{
    public int Id { get; set; }
    public int Distance { get; set; }
    public DateTime Date { get; set; }
    public string? Town { get; set; }
    public string? Status { get; set; }
}