﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BrevetBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class RandonneursController(RandonneursService _service) : ControllerBase
    {
        [HttpGet]
        public RandonneurDto? GetRandonneur(int? id, string? firstname, string? lastname)
        {
            return _service.GetRandonneur(id, firstname, lastname);
        }

        [HttpGet("All")]
        public List<RandoneurWithIsLockedDto> GetAllRandonneurs()
        {
            return _service.GetAllRandonneurs();
        }

        [HttpPut]
        public IActionResult ManageData([FromQuery] RandonneurDto randonneurDto)
        {
            var response = _service.ManageData(randonneurDto);
            return response ? Ok("Ranndoneur erfolgreich bearbeitet!") : BadRequest("Ranndoneur konnte nicht gefunden oder bearbeitet werden!");
        }
    }
}
