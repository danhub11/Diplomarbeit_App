﻿using BrevetBackend.Enums;
using BrevetDbLib;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BrevetBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BrevetsController(BrevetService _service) : ControllerBase
    {
        [HttpGet]
        public List<BrevetDto>? GetBrevetsByYear([FromQuery] int year, [FromQuery] int? accountId, [FromQuery] string? visibilitySettings)
        {
            return _service.GetBrevetsByYear(year, accountId, visibilitySettings)?.Select(x => new BrevetDto().CopyFrom(x)).ToList();
        }

        [HttpPost("Register")]
        public IActionResult AddRandonneurToBrevet([FromQuery] int brevetId, [FromQuery] int accountId, [FromQuery] bool withMedal, [FromQuery] DateTime? desiredDate)
        {
            if (_service.AccountIsLocked(accountId)) return BadRequest("Anmeldung zu Brevet ist fehlgeschlagen, der Account ist gesperrt!");
            if (desiredDate < DateTime.Now) return BadRequest("Das Wunschdatum muss in der Zukunft liegen!");
            var response = _service.AddRandonneurToBrevet(brevetId, accountId, withMedal, desiredDate);
            return response ? Ok("Erfolgreich angemeldet") : BadRequest("Anmeldung fehlgeschlagen");
        }

        [HttpPost]
        public IActionResult CreateNewBrevet([FromBody] BrevetDto brevetDto)
        {
            var response = _service.CreateNewBrevet(brevetDto);
            return response ? Ok("Neues Brevet erfolgreich erstellt!") : BadRequest("Brevet konnte nicht erstellt werden!");
        }

        [HttpPut]
        public IActionResult UpdateBrevet([FromQuery] int id, [FromQuery] int? distance, [FromQuery] DateTime? date, [FromQuery] string? town, [FromQuery] string? status)
        {
            var response = _service.UpdateBrevet(id, distance, date, town, status);
            return response ? Ok("Brevet erfolgreich geändert!") : BadRequest("Brevet konnte nicht geändert werden oder wurde nicht gefunden!");
        }

        [HttpDelete]
        public IActionResult DeleteBrevet(int id)
        {
            var response = _service.DeleteBrevet(id);
            return response ? Ok("Brevet erfolgreich gelöscht!") : BadRequest("Brevet konnte nicht gelöscht werden oder wurde nicht gefunden!");
        }

        [HttpPost("{id}/Copy")]
        public IActionResult CopyBrevet(int id)
        {
            var response = _service.CopyBrevet(id);
            return response ? Ok("Brevet wurde erfolgreich kopiert!") : BadRequest("Brevet konnte nicht gefunden werden oder ist nicht aus dem Vorjahr!");
        }

        [HttpPut("{brevtId}/SignOut")]
        public IActionResult SignOutFromBrevet(int brevtId, int accountId)
        {
            var response = _service.SignOutFromBrevet(brevtId, accountId);
            return response ? Ok("Erfolgreich von Brevet abgemeldet!") : BadRequest(" Abmeldung von Brevet fehlgeschlagen!");
        }

        [HttpGet("User")]
        public List<BrevetWithStatusDto>? GetBrevetsFromUser([FromQuery] int accountID)
        {
            return _service.GetBrevetsFromUser(accountID);
        }

        [HttpGet("Id")]
        public BrevetDto? GetBrevetById([FromQuery] int brevetId)
        {
            return _service.GetBrevetById(brevetId);
        }
    }
}