﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

using BrevetBackend.Services;   // AccountsService
using BrevetBackend.Dtos;        // RegisterDto, LoginDto, RandonneurDto, PasswordDto

namespace BrevetBackend.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AccountsController : ControllerBase
    {
        private readonly AccountsService _service;
        private readonly IConfiguration _configuration;

        public AccountsController(AccountsService service, IConfiguration configuration)
        {
            _service = service;
            _configuration = configuration;
        }

        [HttpPost("Register")]
        public IActionResult Register([FromBody] RegisterDto registerDto)
        {
            if (registerDto.PasswordHash != registerDto.RepeatPassword)
                return BadRequest("Passwörter stimmen nicht überein!");

            if (!_service.EmailIsAvailable(registerDto.Randonneur.Email!))
                return BadRequest("Email existiert schon!");

            var ok = _service.Register(registerDto);
            return ok ? Ok("Account wurde erfolgreich erstellt!") : BadRequest("Account konnte nicht erstellt werden!");
        }

        [HttpPost("Login")]
        public IActionResult Login([FromBody] LoginDto loginDto)
        {
            var user = _service.Login(loginDto);
            if (user == null)
                return BadRequest("Falsche Eingabedaten!");

            // Token lokal hier erzeugen (damit keine Service-Methode nötig ist)
            var token = GenerateJwtToken(user.Id, user.IsAdmin);

            return Ok(new
            {
                token,
                id = user.Id,
                isAdmin = user.IsAdmin,
            });
        }

        [Authorize]
        [HttpGet("profile")]
        public IActionResult GetAccountData()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out var userId))
                return Unauthorized("Ungültiger Token");

            var dto = _service.GetAccountData(userId);
            return dto != null ? Ok(dto) : BadRequest("Etwas ist schief gelaufen!");
        }

        [Authorize]
        [HttpPut("profile")]
        public IActionResult EditAccountData([FromBody] RandonneurDto randonneurDto)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out var userId))
                return Unauthorized("Ungültiger Token");

            var ok = _service.EditAccountData(userId, randonneurDto);
            return ok ? Ok("Die persönlichen Daten wurden erfolgreich bearbeitet!") : BadRequest("Die persönlichen Daten konnten nicht bearbeitet werden");
        }

        [Authorize]
        [HttpPut("{accountId}/Lock")]
        public IActionResult LockAccount(int accountId)
        {
            var isAdminClaim = User.FindFirst("isAdmin")?.Value;
            if (!bool.TryParse(isAdminClaim, out var isAdmin) || !isAdmin)
                return Forbid();

            var ok = _service.LockAccount(accountId);
            return ok ? Ok($"Account mit ID {accountId} wurde erfolgreich gesperrt!") : BadRequest("Account konnte nicht gesperrt oder gefunden werden!");
        }

        [Authorize]
        [HttpPut("{accountId}/Unlock")]
        public IActionResult UnlockAccount(int accountId)
        {
            var isAdminClaim = User.FindFirst("isAdmin")?.Value;
            if (!bool.TryParse(isAdminClaim, out var isAdmin) || !isAdmin)
                return Forbid();

            var ok = _service.UnlockAccount(accountId);
            return ok ? Ok($"Account mit ID {accountId} wurde erfolgreich entsperrt!") : BadRequest("Account konnte nicht entsperrt oder gefunden werden!");
        }

        [HttpPost("{accountId}/UploadProfileImage")]
        public IActionResult UploadProfileImage(int accountId, IFormFile image)
        {
            var ok = _service.UploadProfileImage(accountId, image);
            return ok ? Ok("Profilbild erfolgreich gespeichert.") : BadRequest("Fehlgeschlagen.");
        }

        [HttpGet("{accountId}/ProfileImage")]
        public IActionResult GetProfileImage(int accountId)
        {
            var result = _service.GetProfileImage(accountId);
            if (result == null)
                return NotFound("Kein Bild gefunden.");

            return File(result.Value.FileBytes, result.Value.MimeType);
        }

        [HttpGet("LoginId")]
        public int GetAccountId([FromQuery] Guid loginId)
        {
            return _service.GetAccountId(loginId);
        }

        [Authorize]
        [HttpGet("IsAdmin")]
        public IActionResult GetIsAdmin()
        {
            var isAdmin = User.FindFirst("isAdmin")?.Value == "true";
            return Ok(isAdmin);
        }

        [HttpGet("LoginId/{accountId}")]
        public Guid? GetLoginId(int accountId)
        {
            return _service?.GetLoginId(accountId);
        }

        [HttpGet("GetId/{ranndoneurId}")]
        public int GetAccountIdByRandonneurId(int ranndoneurId)
        {
            return _service.GetAccountIdByRandonneurId(ranndoneurId);
        }

        [HttpGet("GetIsLocked")]
        public bool GetIsLocked(int accountId)
        {
            return _service.GetIsLocked(accountId);
        }

        [Authorize]
        [HttpPut("Password")]
        public IActionResult ChangePassword([FromBody] PasswordDto passwordDto)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out var userId))
                return Unauthorized("Ungültiger Token");

            if (!passwordDto.Password.Equals(passwordDto.PasswordCheck))
                return BadRequest("Passwörter stimmen nicht überein!");

            var ok = _service.ChangePasswort(userId, passwordDto.Password);
            return ok ? Ok("Passwort erfolgreich geändert!") : BadRequest("Passwort konnte nicht geändert werden");
        }

        /// <summary>
        /// Erzeugt ein signiertes JWT. Liest Konfiguration aus appsettings.json → "Jwt": { "Key", "Issuer", "Audience", "ExpiresMinutes" }.
        /// </summary>
        private string GenerateJwtToken(int userId, bool isAdmin)
        {
            var key = _configuration["Jwt:Key"];
            if (string.IsNullOrWhiteSpace(key))
                throw new InvalidOperationException("Jwt:Key ist nicht konfiguriert.");

            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];
            var expiresMinutes = 60;
            if (int.TryParse(_configuration["Jwt:ExpiresMinutes"], out var parsed))
                expiresMinutes = parsed;

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()),
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim("isAdmin", isAdmin.ToString().ToLowerInvariant()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var creds = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);

            var jwt = new JwtSecurityToken(
                issuer: string.IsNullOrWhiteSpace(issuer) ? null : issuer,
                audience: string.IsNullOrWhiteSpace(audience) ? null : audience,
                claims: claims,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.AddMinutes(expiresMinutes),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(jwt);
        }
    }
}
