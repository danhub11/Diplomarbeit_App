﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BrevetBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SettingsController(SettingService _service) : ControllerBase
    {
        [HttpPut("Update")]
        public IActionResult UpdateSetting(int settingId, int accountId, string setting)
        {
            var response = _service.UpdateSetting(settingId, accountId, setting);
            return response ? Ok("Einstellungen wurde erfolgreich gespeichert!") : BadRequest("Einstellungen konnten nicht gespeichert werden");
        }

        [HttpGet("Get")]
        public VisibilitySettingDto? GetSetting()
        {
            return _service.GetSetting();
        }
    }
}
