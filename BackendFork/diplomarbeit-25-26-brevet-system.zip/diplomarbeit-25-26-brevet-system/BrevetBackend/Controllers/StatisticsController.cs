﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BrevetBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class StatisticsController(StatisticService _service) : ControllerBase
    {
        [HttpGet("Finisher")]
        public Dictionary<int, int> FinisherStatsPerYear()
        {
            var currentYear = DateTime.Now.Year;
            var firstYear = 1994;
            var yearFinisher = new Dictionary<int, int>(); 

            for (int year = firstYear; year <= currentYear; year++)
            {
                yearFinisher.Add(year, _service.FinisherStatsPerYear(year));
            }
            return yearFinisher;
        }

        [HttpGet("Starter")]
        public Dictionary<string, int> GetStarterFromCountry()
        {
            var counties = _service.GetAllCountries();
            var starterEachCountry = new Dictionary<string, int>();
            foreach(var country in counties)
            {
                starterEachCountry.Add(country, _service.GetStarterFromCountry(country));
            }
            starterEachCountry.Add("Summe", _service.GetSumOfStarter());
            return starterEachCountry;
        }

        [HttpGet("Year/{year}")]
        public YearStatisticsDto GetStatisticsOfYear(int year)
        {
            return _service.GetStatisticsOfYear(year);
        }
    }
}
