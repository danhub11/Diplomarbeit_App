using BrevetBackend.Dtos;
using BrevetBackend.Enums;
using SQLitePCL;

namespace BrevetBackend.Controllers;

[ApiController]
public class ListsController(ListsService _service) : ControllerBase
{
    [HttpGet("StarterList/{brevetDate}")]
    public List<StarterListDto>? GetStarterList(DateTime brevetDate)
    {
        return _service.GetStarterList(brevetDate);
    }

    [HttpPut("Status")]
    public IActionResult EditStatusInList([FromQuery] ParticipantStatusUpdateDto participantStatusUpdateDto)
    {
        if (Enum.TryParse<ParticipantStatus>(participantStatusUpdateDto.Status, out var status))
        {
            var response = _service.EditStatusInList(participantStatusUpdateDto);
            return response ? Ok("Status wurde erfolgreich ge�ndert!") : NotFound("Der Status konnte nicht ge�ndert werden!");
        }
        else
        {
            return BadRequest("Der Status muss 'DNF', 'DNS', 'FINISHED', oder 'PENDING' sein!");
        }
    }

    [HttpPut("IsPaid")]
    public IActionResult EditIsPaid(int participantId, [FromQuery] bool isPaid)
    {
        var response = _service.EditIsPaid(participantId, isPaid);
        return response ? Ok("IsPaid wurde erfolgreich ge�ndert!") : BadRequest("IsPaid konnte nicht ge�ndern werden!");
    }
}