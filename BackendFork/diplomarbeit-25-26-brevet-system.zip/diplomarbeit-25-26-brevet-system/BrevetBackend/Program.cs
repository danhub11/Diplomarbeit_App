//----------------------------------------
// .Net Core WebApi project create script 
//           v9.2.0 from 2025-01-25
//   (C)Robert Grueneis/HTL Grieskirchen 
//---------------------------------------- 
using BrevetDbLib;
using GrueneisR.RestClientGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

string corsKey = "_myAllowSpecificOrigins";
string swaggerVersion = "v1";
string swaggerTitle = "BrevetBackend";
string restClientFolder = Environment.CurrentDirectory;
string restClientFilename = "_requests.http";

var builder = WebApplication.CreateBuilder(args);

// Von au�en erreichbar machen
builder.WebHost.UseUrls("http://0.0.0.0:5000");

// DB (SQLite per appsettings.json)
var connectionString = builder.Configuration.GetConnectionString("Default") ?? "Data Source=brevet.db";
builder.Services
    .AddDbContext<BrevetContext>(options => options.UseSqlite(connectionString))
    .AddHostedService<BrevetBackend.Services.DbCreationService>();

// Services
builder.Services.AddScoped<BrevetService>();
builder.Services.AddScoped<ListsService>();
builder.Services.AddScoped<StatisticService>();
builder.Services.AddScoped<RandonneursService>();
builder.Services.AddScoped<AccountsService>();
builder.Services.AddScoped<SettingService>();

#region ConfigureServices
builder.Services.AddControllers();

builder.Services
    .AddAuthentication("Bearer")
    .AddJwtBearer("Bearer", options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
        };
    });

builder.Services
  .AddEndpointsApiExplorer()
  .AddAuthorization()
  .AddSwaggerGen(c =>
  {
      c.SwaggerDoc(swaggerVersion, new OpenApiInfo { Title = swaggerTitle, Version = swaggerVersion });

      // JWT in Swagger
      c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
      {
          Description = "JWT mit 'Bearer ' Prefix eingeben. Beispiel: Bearer abc123...",
          Name = "Authorization",
          In = ParameterLocation.Header,
          Type = SecuritySchemeType.ApiKey,
          Scheme = "Bearer"
      });
      c.AddSecurityRequirement(new OpenApiSecurityRequirement
      {
          {
              new OpenApiSecurityScheme
              {
                  Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
              },
              Array.Empty<string>()
          }
      });
  })
  .AddCors(options => options.AddPolicy(
    corsKey,
    x => x.SetIsOriginAllowed(_ => true).AllowAnyMethod().AllowAnyHeader().AllowCredentials()
  ))
  .AddRestClientGenerator(options => options
    .SetFolder(restClientFolder)
    .SetFilename(restClientFilename)
    .SetAction($"swagger/{swaggerVersion}/swagger.json")
  );

builder.Services.AddLogging(x => x.AddCustomFormatter());
#endregion

var app = builder.Build();

#region Middleware
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("++++ Swagger enabled: http://localhost:5000");
    app.UseSwagger();
    Console.WriteLine($@"++++ RestClient generating (after first request) to {restClientFolder}\{restClientFilename}");
    app.UseRestClientGenerator();
    app.UseSwaggerUI(x => x.SwaggerEndpoint($"/swagger/{swaggerVersion}/swagger.json", swaggerTitle));
    Console.ResetColor();
}

app.UseCors(corsKey);
//app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
#endregion

app.Map("/", () => Results.Redirect("/swagger"));
app.MapControllers();
Console.WriteLine($"Ready for clients at {DateTime.Now:HH:mm:ss} ...");
app.Run();
