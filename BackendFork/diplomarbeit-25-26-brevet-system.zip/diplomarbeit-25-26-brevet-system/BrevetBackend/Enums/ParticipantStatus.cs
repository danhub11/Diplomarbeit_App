﻿namespace BrevetBackend.Enums
{
    public enum ParticipantStatus
    {
        FINISHED,
        DNS,
        DNF,
        PENDING
    }
}
