﻿using BrevetDbLib;

namespace BrevetBackend.Services
{
    public class RandonneursService(BrevetContext _db)
    {
        public RandonneurDto? GetRandonneur(int? id, string? fistname, string? lastname)
        {
            var randonneur = _db.Randonneurs.FirstOrDefault(x => x.Id == id || x.Firstname == fistname && x.Lastname == lastname);
            if (randonneur == null) return null;
            return new RandonneurDto().CopyFrom(randonneur);
        }

        public List<RandoneurWithIsLockedDto> GetAllRandonneurs()
        {
            var ranndoneurs = _db.Randonneurs.ToList();
            var response = new  List<RandoneurWithIsLockedDto>();
            foreach (var randoneur in ranndoneurs)
            {
                var account = _db.Accounts.FirstOrDefault(x => x.Randonneur.Id == randoneur.Id);
                response.Add(new RandoneurWithIsLockedDto()
                {
                    AccountId = account != null ? account.Id : -1,
                    IsLocked = account != null ? account.IsLocked : false,
                }.CopyFrom(randoneur));
            }
            return response;
        }

        public bool ManageData(RandonneurDto randonneurDto)
        {
            var ranndoneur = _db.Randonneurs.FirstOrDefault(x => x.Id == randonneurDto.Id);
            if (ranndoneur == null) return false;

            ranndoneur.Firstname = randonneurDto.Firstname ?? ranndoneur.Firstname;
            ranndoneur.Lastname = randonneurDto.Lastname ?? ranndoneur.Lastname;
            ranndoneur.DateOfBirth = randonneurDto.DateOfBirth ?? ranndoneur.DateOfBirth;
            ranndoneur.Address = randonneurDto.Address ?? ranndoneur.Address;
            ranndoneur.PLZ = randonneurDto.PLZ ?? ranndoneur.PLZ;
            ranndoneur.City = randonneurDto.City ?? ranndoneur.City;
            ranndoneur.Country = randonneurDto.Country ?? ranndoneur.Country;
            ranndoneur.Email = randonneurDto.Email ?? ranndoneur.Email;
            ranndoneur.PhoneNumber = randonneurDto.PhoneNumber ?? ranndoneur.PhoneNumber;

            _db.Randonneurs.Update(ranndoneur);
            return _db.SaveChanges() > 0;
        }
    }
}