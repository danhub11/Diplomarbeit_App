﻿using BrevetBackend.Enums;
using BrevetDbLib;
using Microsoft.EntityFrameworkCore;

namespace BrevetBackend.Services
{
    public class ListsService(BrevetContext _db)
    {
        public List<StarterListDto>? GetStarterList(DateTime brevetDate)
        {
            return _db.Participants
                .Where(p => p.Brevet != null && p.Brevet.Date == brevetDate)
                .Include(p => p.Randonneur).Include(p => p.Brevet)
                .ToList()
                .Select(p => new StarterListDto
                {
                    Id = p.Id,
                    Lastname = p.Randonneur!.Lastname,
                    Firstname = p.Randonneur.Firstname,
                    Location = p.Randonneur.City,
                    Country = p.Randonneur.Country,
                    WithMedal = p.WithMedal,
                    Status = p.Status,
                    Paid = p.Paid,
                    HomologationNr = p.HomologationNr,
                    BrevetId = p.Brevet.Id
                })
                .OrderBy(x => x.Lastname)
                .ToList();
        }

        public bool EditStatusInList(ParticipantStatusUpdateDto participantStatusUpdateDto)
        {
            var participant = _db.Participants.FirstOrDefault(x => x.Id == participantStatusUpdateDto.ParticipantId);
            if (participant == null) return false;
            participant.Status = participantStatusUpdateDto.Status.ToUpper();
            if(participant.Status == ParticipantStatus.FINISHED.ToString())
            {
                var homologationNr = _db.Participants.Select(x => x.HomologationNr).Max() + 1;
                participant.HomologationNr = homologationNr;
            }
            _db.Participants.Update(participant);
            return _db.SaveChanges() > 0;
        }

        public bool EditIsPaid(int participantId, bool isPaid)
        {
            var participant = _db.Participants.FirstOrDefault(x => x.Id == participantId);
            if (participant == null) return false;
            participant.Paid = isPaid;
            _db.Update(participant);
            return _db.SaveChanges() > 0;
        }
    }
}
