﻿using BrevetBackend.Enums;
using BrevetDbLib;
using Microsoft.EntityFrameworkCore;
using NuGet.Frameworks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BrevetBackend.Services;

public class BrevetService(BrevetContext _db)
{
    public List<Brevet>? GetBrevetsByYear(int year, int? accountId, string? visibilitySettings)
    {
        if (accountId != null || visibilitySettings != null && visibilitySettings.Equals("nur für Teilnehmer des Brevets"))
        {
            var account = _db.Accounts
                        .Include(x => x.Randonneur)
                        .FirstOrDefault(x => x.Id == accountId);
            if (account == null) return null;

            var ranndoneur = account.Randonneur;
            if (ranndoneur == null) return null;

            var participants = _db.Participants
                .Include(x => x.Randonneur)
                .Include(x => x.Brevet)
                .Where(x => x.Randonneur == ranndoneur && x.Brevet.Date.Year == year)
                .Select(x => x.Brevet)
                .ToList();

            return participants;
        }
        else
        {
            return _db.Brevets.Where(x => x.Date.Year == year).OrderBy(x => x.Date).ToList();
        }
    }


    public bool AddRandonneurToBrevet(int brevetId, int accountId, bool withMedal, DateTime? desiredDate)
    {
        var account = _db.Accounts.Include(x => x.Randonneur).FirstOrDefault(x => x.Id == accountId);
        if (account == null) return false;
        var randonneur = account.Randonneur;
        var searchRandonneur = _db.Randonneurs.FirstOrDefault(x => x.Firstname == randonneur.Firstname && x.Lastname == randonneur.Lastname && x.Address == randonneur.Address);

        if (searchRandonneur == null)
        {
            _db.Randonneurs.Add(randonneur);
            _db.SaveChanges();
        }
        else
        {
            randonneur = searchRandonneur;
        }

        var brevet = _db.Brevets.FirstOrDefault(x => x.Id == brevetId);
        if (brevet == null) return false;

        if (_db.Participants.FirstOrDefault(x => x.Randonneur.Id == randonneur.Id && x.Brevet.Id == brevet.Id) != null)
            return false;

        var participant = new Participant
        {
            Randonneur = randonneur,
            WithMedal = withMedal,
            Status = ParticipantStatus.PENDING.ToString(),
            Brevet = brevet,
        };

        var emailService = new EmailService();
        if (desiredDate != null && randonneur != null)
        {
            emailService.SendDesiredDate(desiredDate, randonneur, brevet);
        }

        if (randonneur != null)
        {
            emailService.SendPaymentInformation(randonneur, brevet, withMedal);
        }
        _db.Participants.Add(participant);
        return _db.SaveChanges() > 0;
    }

    public bool AccountIsLocked(int accountId)
    {
        var account = _db.Accounts.FirstOrDefault(x => x.Id == accountId);
        if (account!.IsLocked || account == null)
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    public bool CreateNewBrevet(BrevetDto brevetDto)
    {
        var brevet = new Brevet().CopyFrom(brevetDto);
        brevet.Status = ParticipantStatus.PENDING.ToString();
        _db.Brevets.Add(brevet);
        return _db.SaveChanges() > 0;
    }

    public bool UpdateBrevet(int id, int? distance, DateTime? date, string? town, string? status)
    {
        var brevet = _db.Brevets.FirstOrDefault(x => x.Id == id);
        if (brevet == null) return false;

        brevet.Distance = distance ?? brevet.Distance;
        brevet.Date = date ?? brevet.Date;
        brevet.Town = town ?? brevet.Town;
        brevet.Status = status ?? brevet.Status;

        _db.Brevets.Update(brevet);
        return _db.SaveChanges() > 0;
    }

    public bool DeleteBrevet(int id)
    {
        var brevet = _db.Brevets.FirstOrDefault(x => x.Id == id);
        if (brevet == null) return false;
        _db.Brevets.Remove(brevet);
        return _db.SaveChanges() > 0;
    }

    public bool CopyBrevet(int id)
    {
        var brevet = _db.Brevets.FirstOrDefault(x => x.Id == id);
        if (brevet == null || brevet.Date.Year != DateTime.Now.Year - 1) return false;
        var brevetCopy = new Brevet
        {
            Distance = brevet.Distance,
            Date = brevet.Date.AddYears(1),
            Town = brevet.Town,
            Status = brevet.Status,
        };
        _db.Brevets.Add(brevetCopy);
        return _db.SaveChanges() > 0;
    }

    public bool SignOutFromBrevet(int brevetId, int accountId)
    {
        var account = _db.Accounts.FirstOrDefault(x => x.Id == accountId);
        if (account == null) return false;
        var participant = _db.Participants.FirstOrDefault(x => x.Brevet.Id == brevetId && x.Randonneur.Id == account.RandonneurId);
        if (participant == null) return false;
        participant.Status = ParticipantStatus.DNS.ToString();
        _db.Update(participant);
        return _db.SaveChanges() > 0;
    }

    public List<BrevetWithStatusDto>? GetBrevetsFromUser(int accountId)
    {
        var account = _db.Accounts.Include(x => x.Randonneur).FirstOrDefault(x => x.Id == accountId);
        if (account == null) return null;
        var ranndoneur = account.Randonneur;
        var brevets = _db.Participants
            .Include(x => x.Randonneur).Include(x => x.Brevet)
            .Where(x => x.Randonneur.Id == ranndoneur.Id).ToList().OrderByDescending(x => x.Brevet.Date);
        var brevetDtoList = new List<BrevetWithStatusDto>();
        foreach (var x in brevets)
        {
            var brevetDto = new BrevetWithStatusDto
            {
                Id = x.Brevet.Id,
                Distance = x.Brevet.Distance,
                Date = x.Brevet.Date,
                Town = x.Brevet.Town,
                ParticipantStatus = x.Status,
            };
            brevetDtoList.Add(brevetDto);
        }
        return brevetDtoList;
    }

    public BrevetDto? GetBrevetById(int brevetId)
    {
        var brevet = _db.Brevets.FirstOrDefault(x => x.Id == brevetId);
        if (brevet == null) return null;
        return new BrevetDto().CopyFrom(brevet);
    }
}