﻿using BrevetBackend.Enums;
using BrevetDbLib;

namespace BrevetBackend.Services;

public class DbCreationService(IServiceProvider serviceProvider) : BackgroundService
{
    private BrevetContext _db = null!;

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        Console.WriteLine("Crating BrevetContext");
        using var scope = serviceProvider.CreateScope();
        _db = scope.ServiceProvider.GetRequiredService<BrevetContext>();
        //Console.WriteLine("EnsureDeleted"); _db.Database.EnsureDeleted();
        Console.WriteLine("EnsureCreated"); _db.Database.EnsureCreated();
        Seed();
        InsertTown();
        Console.WriteLine($"Numbers in Randonneurs {_db.Randonneurs.Count()}");
        Console.WriteLine("Database created");
        return Task.CompletedTask;
    }

    private void Seed()
    {
        if (_db.Randonneurs.Any()) return;

        //Randonneurs
        var randonneurs = new List<Randonneur>();
        randonneurs.AddRange(
            File.ReadAllLines("Files/Brevets.csv")
            .Skip(1)
            .Select(line =>
            {
                var parts = line.Split(",");
                var addressParts = parts[2].Split(" ");
                int plz = 0;
                string city = "";

                if (addressParts.Length >= 2)
                {
                    int.TryParse(addressParts[0].Trim('"'), out plz);
                    city = string.Join(" ", addressParts.Skip(1));
                }
                else
                {
                    city = parts[2].Trim('"');
                }

                return new Randonneur
                {
                    Lastname = parts[0].Trim('"'),
                    Firstname = parts[1].Trim('"'),
                    PLZ = plz,
                    City = city.Trim('"'),
                    Country = parts[3].Trim('"')
                };
            })
        );
        var sortedRandonneurs = randonneurs.DistinctBy(x => (x.Lastname.Trim().ToLower(), x.Firstname.Trim().ToLower())).ToList();
        _db.Randonneurs.AddRange(sortedRandonneurs);
        _db.SaveChanges();

        //Brevets
        var row = 0;
        var brevets = new List<Brevet>();
        brevets.AddRange(
            File.ReadAllLines("Files/Brevets.csv")
            .Skip(1)
            .Select(line =>
            {
                var parts = line.Split(",");
                row++;
                return new Brevet
                {
                    Distance = int.Parse(parts[4].Trim('"')),
                    Date = ParseDate(parts[5].Trim('"')),
                    Status = DateTime.Now > ParseDate(parts[5].Trim('"')) ? "abgeschlossen" : "offen",
                };
            })
        );
        var sortetBrevets = brevets.DistinctBy(x => x.Date).ToList();
        _db.Brevets.AddRange(sortetBrevets);
        _db.SaveChanges();

        //Participants
        var participants = new List<Participant>();
        participants.AddRange(
            File.ReadAllLines("Files/Brevets.csv")
            .Skip(1)
            .Select(line =>
            {
                var parts = line.Split(",");
                var randonneur = _db.Randonneurs.FirstOrDefault(x => x.Firstname == parts[1].Trim('"') && x.Lastname == parts[0].Trim('"'));
                var brevet = _db.Brevets.FirstOrDefault(x => x.Date == ParseDate(parts[5].Trim('"')));

                var homologationStr = parts[6].Trim('"');
                int homologationNr = 0;

                if (!string.IsNullOrEmpty(homologationStr) && int.TryParse(homologationStr, out var parsedNr))
                {
                    homologationNr = parsedNr;
                }
                else
                {
                    homologationNr = 0;
                }

                return new Participant
                {
                    HomologationNr = homologationNr,
                    Status = CheckStatus(homologationNr, brevet!),
                    Randonneur = randonneur!,
                    Brevet = brevet!,
                };
            })
        );
        _db.Participants.AddRange(participants);
        _db.SaveChanges();

        //Settings
        var setting = new VisibilitySetting
        {
            Setting = "für alle"
        };
        _db.VisibilitySettings.Add(setting);
        _db.SaveChanges();
    }

    private static DateTime ParseDate(string input)
    {
        string[] formats = { "M/d/yyyy", "d.M.yyyy", "dd.MM.yyyy", "MM.dd.yyyy" };
        if (DateTime.TryParseExact(input, formats, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var date))
            return date;
        throw new FormatException($"Ungültiges Datumsformat: {input}");
    }

    private string CheckStatus(int homologationNr, Brevet brevet)
    {
        if (brevet.Date > DateTime.Now)
        {
            return ParticipantStatus.PENDING.ToString();
        }
        else
        {
            return homologationNr > 0 ? ParticipantStatus.FINISHED.ToString() : ParticipantStatus.DNS.ToString();
        }
    }

    private void InsertTown()
    {
        var brevets = _db.Brevets.ToList();
        foreach (var brevet in brevets)
        {
            if (brevet != null && brevet.Date.Year >= 2012)
            {
                brevet.Town = "Haid";
            }
            else if (brevet != null)
            {
                brevet.Town = "-";
            }
        }
        _db.SaveChanges();

        var brevetDateCity = new Dictionary<DateTime, string>
        {
            //2012
            [new DateTime(2012, 8, 18)] = "St. Georgen",
            [new DateTime(2012, 8, 19)] = "St. Georgen",
            //2018
            [new DateTime(2018, 5, 5)] = "St. Georgen",
            //2019
            [new DateTime(2019, 4, 27)] = "St. Georgen",
            [new DateTime(2019, 5, 5)] = "Weiden am See",
            [new DateTime(2019, 5, 1)] = "St. Georgen",
            [new DateTime(2019, 5, 4)] = "Weiden am See",
            [new DateTime(2019, 6, 20)] = "Bregenz",
            //2020
            [new DateTime(2020, 8, 2)] = "Weiden am See",
            [new DateTime(2020, 8, 8)] = "Weiden am See",
            [new DateTime(2020, 8, 22)] = "St. Georgen",
            //2021
            [new DateTime(2021, 8, 21)] = "St. Georgen",
            [new DateTime(2021, 9, 4)] = "Weiden am See",
            [new DateTime(2021, 9, 4)] = "Weiden am See",
            [new DateTime(2021, 5, 22)] = "Traun",
            [new DateTime(2021, 5, 23)] = "Traun",
            //2022
            [new DateTime(2022, 5, 7)] = "St. Georgen",
            [new DateTime(2022, 9, 3)] = "Weiden am See",
            //2023
            [new DateTime(2023, 5, 6)] = "St. Georgen",
            [new DateTime(2023, 5, 7)] = "St. Georgen",
            [new DateTime(2023, 5, 20)] = "Mariazell",
            //2024
            [new DateTime(2024, 4, 11)] = "Mallorca",
            [new DateTime(2024, 5, 4)] = "St. Georgen",
            [new DateTime(2024, 5, 5)] = "St. Georgen",
            [new DateTime(2024, 6, 8)] = "Mariazell",
            //2025
            [new DateTime(2025, 4, 26)] = "Pucking",
            [new DateTime(2025, 4, 26)] = "Pucking",
            [new DateTime(2025, 5, 3)] = "St. Georgen",
            [new DateTime(2025, 5, 4)] = "St. Georgen",
        };

        foreach (var item in brevetDateCity)
        {
            var brevet = _db.Brevets.FirstOrDefault(x => x.Date == item.Key);
            if (brevet != null)
            {
                brevet.Town = item.Value;
            }
        }
        _db.SaveChanges();
    }
}