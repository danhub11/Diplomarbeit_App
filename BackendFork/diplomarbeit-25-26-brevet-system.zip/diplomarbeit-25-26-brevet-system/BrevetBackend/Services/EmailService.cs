﻿using BrevetDbLib;
using System.Net;
using System.Net.Mail;

namespace BrevetBackend.Services;

public class EmailService
{
    public void SendDesiredDate(DateTime? desiredDate, Randonneur randonneur, Brevet brevet)
    {
        if (randonneur.Email == null || !desiredDate.HasValue) return;

        string from = "alexburgholzer8@gmail.com";
        string passwort = "ybllesgrjtsjremd";
        string to = "alexburgholzer8@gmail.com";

        var mailToManager = new MailMessage(from, to)
        {
            Subject = $"Wunschdatum für Brevet {brevet.Distance} {brevet.Town}",
            Body = $"Der Randonneur {randonneur.Firstname} {randonneur.Lastname} hat als Wunschdatum {desiredDate:dd.MM.yyyy} für das Brevet {brevet.Distance} {brevet.Town} angegeben."
        };

        mailToManager.ReplyToList.Add(new MailAddress(randonneur.Email));

        var mailToRanndoneur = new MailMessage(from, randonneur.Email)
        {
            Subject = $"Eingang deines Wunschtermins",
            Body = $"Hallo {randonneur.Firstname}, \n\n dein Wunschtermin am {desiredDate:dd.MM.yyyy} wurde erfolgreich übermittelt. Wir melden uns bald bei dir!"
        };

        using var smtp = new SmtpClient("smtp.gmail.com", 587)
        {
            Credentials = new NetworkCredential(from, passwort),
            EnableSsl = true
        };

        smtp.Send(mailToManager);
        smtp.Send(mailToRanndoneur);
    }

    public void SendId(Randonneur randonneur, Account account)
    {
        if (randonneur.Email == null) return;

        string from = "alexburgholzer8@gmail.com";
        string passwort = "ybllesgrjtsjremd";

        var mailToRanndoneur = new MailMessage(from, randonneur.Email)
        {
            Subject = $"Erfolgreiche Registrierung",
            Body = $"Hallo {randonneur.Firstname}, \n\n" +
            $"du hast dich erfolgreich bei uns registriert. Deine ID lautet: {account.LoginId} \n\n " +
            $"Mit dieser ID und deinem Passwort kannst du dich auf unserer Webseite einloggen! \n\n" +
            $"Mit freundlichen Grüßen \n" +
            $"Das Randonneur-Team"
        };

        using var smpt = new SmtpClient("smtp.gmail.com", 587)
        {
            Credentials = new NetworkCredential(from, passwort),
            EnableSsl = true
        };
        smpt.Send(mailToRanndoneur);
    }

    public void SendPaymentInformation(Randonneur randonneur, Brevet brevet, bool withMedal)
    {
        int amount = 0;
        if (withMedal)
        {
            switch (brevet.Distance)
            {
                case < 600:
                    amount = 27;
                    break;
                case 600:
                    amount = 31;
                    break;
                case 1000:
                    amount = 80;
                    break;
            }
        }
        else
        {
            switch (brevet.Distance)
            {
                case < 600:
                    amount = 20;
                    break;
                case 600:
                    amount = 24;
                    break;
                case 1000:
                    amount = 70;
                    break;
            }
        }

        if (randonneur.Email == null) return;
        string from = "alexburgholzer8@gmail.com";
        string passwort = "ybllesgrjtsjremd";

        var mailToRanndoneur = new MailMessage(from, randonneur.Email)
        {
            Subject = $"Zahlungsinformation für das {brevet.Distance} km Brevet",
            Body =  $"Hallo {randonneur.Firstname},\n\n" +
                    $"vielen Dank für deine Anmeldung zum {brevet.Distance} km Brevet am {brevet.Date:dd.MM.yyyy}!\n\n" +
                    $"Bitte überweise den Unkostenbeitrag spätestens eine Woche vor dem Start auf das unten angeführte Konto. " +
                    $"Ansonsten fällt eine Nachmeldegebühr von 5,00 EUR an. Bitte beobachte deinen Status auf der jeweiligen Starterliste.\n\n" +

                    $"Empfänger: Ferdinand Jung\n" +
                    $"IBAN: AT612032016802027233\n" +
                    $"BIC: ASPKAT2LXXX\n" +
                    $"Betrag: {amount} EUR\n\n" +

                    $"Die mit * gekennzeichneten Brevets sind ohne Labe und ohne Essen im Ziel. Dafür beträgt der Unkostenbeitrag 10,– EUR.\n" +
                    $"Beim 600 km Brevet Mariazell wird bis zur Labestelle bei km  148 Verpflegung angeboten.\n\n" +

                    $"Mit sportlichen Grüßen\n" +
                    $"Dein Randonneur-Team"
        };

        using var smpt = new SmtpClient("smtp.gmail.com", 587)
        {
            Credentials = new NetworkCredential(from, passwort),
            EnableSsl = true
        };
        smpt.Send(mailToRanndoneur);
    }
}