﻿using System;
using System.IO;
using System.Linq;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BrevetBackend.Dtos;
using BrevetDbLib;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace BrevetBackend.Services
{
    /// <summary>
    /// Vereinheitlichte, konfliktfreie Version:
    /// - Klassenname: AccountsService (nicht AccountsSevice)
    /// - Konstruktor-Injections: BrevetContext, IWebHostEnvironment, IConfiguration
    /// - Enthält sowohl Profilbild-Features als auch JWT-Erzeugung
    /// </summary>
    public class AccountsService
    {
        private readonly BrevetContext _db;
        private readonly IWebHostEnvironment _env;
        private readonly IConfiguration _configuration;

        public AccountsService(BrevetContext db, IWebHostEnvironment env, IConfiguration configuration)
        {
            _db = db;
            _env = env;
            _configuration = configuration;
        }

        // -------------------------- Auth & Accounts --------------------------

        public bool Register(RegisterDto dto)
        {
            if (dto?.Randonneur == null) return false;

            // Sicherheitscheck (Race-Condition verhindern)
            var email = dto.Randonneur.Email?.Trim();
            if (!string.IsNullOrWhiteSpace(email) &&
                _db.Randonneurs.Any(r => r.Email == email))
                return false;

            // Randonneur suchen (besser über E-Mail als über Name/PLZ/Ort)
            var randonneur = _db.Randonneurs
                .SingleOrDefault(r => r.Email == email);

            if (randonneur == null)
            {
                randonneur = new Randonneur().CopyFrom(dto.Randonneur);
            }
            else
            {
                // Bestehende Person aktualisieren
                randonneur.DateOfBirth = dto.Randonneur.DateOfBirth;
                randonneur.PhoneNumber = dto.Randonneur.PhoneNumber;
                randonneur.Address = dto.Randonneur.Address;
                randonneur.PLZ = dto.Randonneur.PLZ;
                randonneur.City = dto.Randonneur.City;
                randonneur.Country = dto.Randonneur.Country;
                randonneur.Firstname = dto.Randonneur.Firstname;
                randonneur.Lastname = dto.Randonneur.Lastname;
            }

            // Kein zweites Account für dieselbe Person
            if (randonneur.Id != 0 &&
                _db.Accounts.Any(a => a.RandonneurId == randonneur.Id))
                return false;

            var account = new Account
            {
                PasswordHash = PasswordHelper.HashPassword(dto.PasswordHash),
                IsAdmin = false,
                LoginId = Guid.NewGuid(),
                Randonneur = randonneur
            };

            // EF sauber anweisen: neu oder update
            if (randonneur.Id == 0)
                _db.Randonneurs.Add(randonneur);
            else
                _db.Randonneurs.Update(randonneur);

            _db.Accounts.Add(account);

            try
            {
                // Erst speichern …
                var changed = _db.SaveChanges() > 0;

                if (!changed) return false;

                // … dann E-Mail senden (damit bei Fehler kein 400 + E-Mail entsteht)
                try
                {
                    var emailService = new EmailService();
                    emailService.SendId(randonneur, account);
                }
                catch (Exception mailEx)
                {
                    // optional: loggen, aber Account bleibt angelegt
                    Console.WriteLine($"E-Mail Versand fehlgeschlagen: {mailEx.Message}");
                }

                return true;
            }
            catch (DbUpdateException dbEx)
            {
                Console.WriteLine(dbEx);
                return false;
            }
        }

        public bool EmailIsAvailable(string email)
        {
            var check = _db.Randonneurs.FirstOrDefault(x => x.Email == email);
            return check == null;
        }

        public LoginReturnDto? Login(LoginDto loginDto)
        {
            var hash = PasswordHelper.HashPassword(loginDto.Password);
            Account? account;

            // GUID?
            if (Guid.TryParse(loginDto.LoginId, out var guid))
            {
                account = _db.Accounts.FirstOrDefault(a => a.LoginId == guid && a.PasswordHash == hash);
            }
            else
            {
                // sonst E-Mail
                account = _db.Accounts
                    .Include(a => a.Randonneur)
                    .FirstOrDefault(a => a.Randonneur.Email == loginDto.LoginId && a.PasswordHash == hash);
            }

            if (account == null) return null;

            return new LoginReturnDto
            {
                Id = account.Id,
                IsAdmin = account.IsAdmin
            };
        }


        // -------------------------- JWT Token --------------------------

        /// <summary>
        /// Erzeugt ein signiertes JWT basierend auf "Jwt" aus appsettings.json.
        /// Erzeugt Claims: sub(NameIdentifier), isAdmin, jti
        /// </summary>
        public string GenerateJwtToken(int userId, bool isAdmin)
        {
            var keyStr = _configuration["Jwt:Key"];
            if (string.IsNullOrWhiteSpace(keyStr))
                throw new InvalidOperationException("Jwt:Key ist nicht konfiguriert.");

            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];

            // Optional: "Jwt:ExpireHours" (Fallback 2h)
            double expireHours = 2;
            if (double.TryParse(_configuration["Jwt:ExpireHours"], out var parsed))
                expireHours = parsed;

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()),
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim("isAdmin", isAdmin.ToString().ToLowerInvariant()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(keyStr));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: string.IsNullOrWhiteSpace(issuer) ? null : issuer,
                audience: string.IsNullOrWhiteSpace(audience) ? null : audience,
                claims: claims,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.AddHours(expireHours),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        // -------------------------- Profilbild --------------------------

        public bool UploadProfileImage(int accountId, IFormFile image)
        {
            if (image == null || image.Length == 0) return false;

            var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "profileImages");
            Directory.CreateDirectory(uploadsFolder);

            var account = _db.Accounts.FirstOrDefault(a => a.Id == accountId);
            if (account == null) return false;

            // altes Bild löschen, falls vorhanden
            if (!string.IsNullOrEmpty(account.ProfileImagePath))
            {
                var oldRelPath = account.ProfileImagePath.TrimStart('/', '\\');
                var oldFilePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", oldRelPath);
                if (File.Exists(oldFilePath))
                {
                    try { File.Delete(oldFilePath); } catch { /* ignore */ }
                }
            }

            var fileName = $"profile_{accountId}{Path.GetExtension(image.FileName)}";
            var filePath = Path.Combine(uploadsFolder, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                image.CopyTo(stream);
            }

            account.ProfileImagePath = $"/profileImages/{fileName}";
            _db.SaveChanges();

            return true;
        }

        public (byte[] FileBytes, string MimeType)? GetProfileImage(int accountId)
        {
            var user = _db.Accounts.FirstOrDefault(a => a.Id == accountId);
            if (user == null || string.IsNullOrEmpty(user.ProfileImagePath))
                return null;

            var relative = user.ProfileImagePath.TrimStart('/', '\\');
            var fullPath = Path.Combine(_env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"), relative);

            if (!File.Exists(fullPath))
                return null;

            var fileBytes = File.ReadAllBytes(fullPath);
            var ext = Path.GetExtension(fullPath).Trim('.').ToLower();
            var mimeType = $"image/{(ext == "jpg" ? "jpeg" : ext)}";
            return (fileBytes, mimeType);
        }

        // -------------------------- Account-Daten --------------------------

        public RandonneurDto? GetAccountData(int id)
        {
            var account = _db.Accounts.Include(x => x.Randonneur).FirstOrDefault(x => x.Id == id);
            if (account == null) return null;

            return new RandonneurDto
            {
                Id = account.Randonneur.Id,
                Firstname = account.Randonneur.Firstname,
                Lastname = account.Randonneur.Lastname,
                DateOfBirth = account.Randonneur.DateOfBirth,
                Address = account.Randonneur.Address,
                PLZ = account.Randonneur.PLZ,
                City = account.Randonneur.City,
                Country = account.Randonneur.Country,
                Email = account.Randonneur.Email,
                PhoneNumber = account.Randonneur.PhoneNumber,
                ProfileImagePath = account.ProfileImagePath
            };
        }

        public bool EditAccountData(int accountId, RandonneurDto randonneurDto)
        {
            var account = _db.Accounts.Include(x => x.Randonneur).FirstOrDefault(x => x.Id == accountId);
            if (account == null || account.Randonneur == null) return false;

            account.Randonneur.Firstname = randonneurDto.Firstname ?? account.Randonneur.Firstname;
            account.Randonneur.Lastname = randonneurDto.Lastname ?? account.Randonneur.Lastname;
            account.Randonneur.DateOfBirth = randonneurDto.DateOfBirth ?? account.Randonneur.DateOfBirth;
            account.Randonneur.Address = randonneurDto.Address ?? account.Randonneur.Address;
            account.Randonneur.PLZ = randonneurDto.PLZ ?? account.Randonneur.PLZ;
            account.Randonneur.City = randonneurDto.City ?? account.Randonneur.City;
            account.Randonneur.Country = randonneurDto.Country ?? account.Randonneur.Country;
            account.Randonneur.Email = randonneurDto.Email ?? account.Randonneur.Email;
            account.Randonneur.PhoneNumber = randonneurDto.PhoneNumber ?? account.Randonneur.PhoneNumber;

            _db.Randonneurs.Update(account.Randonneur);
            return _db.SaveChanges() > 0;
        }

        public bool LockAccount(int accountId)
        {
            var account = _db.Accounts.FirstOrDefault(x => x.Id == accountId);
            if (account == null) return false;
            account.IsLocked = true;
            _db.Accounts.Update(account);
            return _db.SaveChanges() > 0;
        }

        public bool UnlockAccount(int accountId)
        {
            var account = _db.Accounts.FirstOrDefault(x => x.Id == accountId);
            if (account == null) return false;
            account.IsLocked = false;
            _db.Accounts.Update(account);
            return _db.SaveChanges() > 0;
        }

        public int GetAccountId(Guid loginId)
        {
            var account = _db.Accounts.FirstOrDefault(x => x.LoginId == loginId);
            return account?.Id ?? -1;
        }

        public bool GetIsAdmin(int accountId)
        {
            var account = _db.Accounts.FirstOrDefault(x => x.Id == accountId);
            return account != null && account.IsAdmin;
        }

        public Guid? GetLoginId(int accountId)
        {
            return _db.Accounts.FirstOrDefault(x => x.Id == accountId)?.LoginId;
        }

        public int GetAccountIdByRandonneurId(int randonneurId)
        {
            var account = _db.Accounts.Include(x => x.Randonneur).FirstOrDefault(x => x.Randonneur.Id == randonneurId);
            return account?.Id ?? -1;
        }

        public bool GetIsLocked(int accountId)
            => _db.Accounts.FirstOrDefault(x => x.Id == accountId)!.IsLocked;

        public bool ChangePasswort(int id, string password)
        {
            var account = _db.Accounts.Include(x => x.Randonneur).FirstOrDefault(x => x.Id == id);
            if (account == null) return false;

            var passwordHash = PasswordHelper.HashPassword(password);
            account.PasswordHash = passwordHash;
            _db.Accounts.Update(account);
            return _db.SaveChanges() > 0;
        }
    }
}
