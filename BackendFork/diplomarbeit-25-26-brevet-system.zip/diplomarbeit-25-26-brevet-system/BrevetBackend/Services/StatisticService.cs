﻿using BrevetBackend.Enums;
using BrevetDbLib;
using Microsoft.EntityFrameworkCore;

namespace BrevetBackend.Services;
public class StatisticService(BrevetContext _db)
{
    public int FinisherStatsPerYear(int year) =>
        year == 1994 ?
        _db.Participants.Where(x => x.Brevet.Date.Year == year).ToList().Count :
        _db.Participants.Where(x => x.Brevet.Date.Year == year && x.HomologationNr > 0).ToList().Count;

    public int GetStarterFromCountry(string country) =>
        _db.Randonneurs.Where(x => x.Country == country).ToList().Count;

    public List<string> GetAllCountries() =>
        _db.Randonneurs.Select(x => x.Country).Distinct().ToList();

    public int GetSumOfStarter() =>
        _db.Randonneurs.Count();

    public YearStatisticsDto GetStatisticsOfYear(int year)
    {
        var participants = _db.Participants.Include(x => x.Brevet).Include(x => x.Randonneur).Where(x => x.Brevet.Date.Year == year).ToList();
        var amount200 = participants.Where(x => x.Brevet.Distance == 200).Count();
        var amount300 = participants.Where(x => x.Brevet.Distance == 300).Count();
        var amount400 = participants.Where(x => x.Brevet.Distance == 400).Count();
        var amount600 = participants.Where(x => x.Brevet.Distance == 600).Count();
        var amount1000 = participants.Where(x => x.Brevet.Distance == 1000).Count();
        var sumKm = amount1000 * 1000 + amount600 * 600 + amount400 *400 + amount300 *300 + amount200 * 200;
        var finishedAmount = participants.Where(x => x.Status == ParticipantStatus.FINISHED.ToString()).Count();

        return new YearStatisticsDto
        {
            Year = year,
            TwoHundresKm = amount200,
            ThreeHundresKm = amount300,
            FourHundresKm = amount400,
            SixHundresKm = amount600,
            ThousandKm = amount1000,
            KilometerSum = sumKm,
            Finisher = finishedAmount,
        };
    }
}
