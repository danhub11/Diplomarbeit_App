﻿using BrevetDbLib;
using Microsoft.EntityFrameworkCore;

namespace BrevetBackend.Services;

public class SettingService(BrevetContext _db)
{
    public bool UpdateSetting(int settingId, int accountId, string setting)
    {
        var account = _db.Accounts.FirstOrDefault(x => x.Id == accountId);
        if (account == null) return false;

        if (account.IsAdmin)
        {
            var visibilitySetting = _db.VisibilitySettings.FirstOrDefault(x => x.Id == settingId);
            if (visibilitySetting != null)
            {
                visibilitySetting.Setting = setting;
                _db.VisibilitySettings.Update(visibilitySetting);
                return _db.SaveChanges() > 0;
            }
            return false;
        }
        else
        {
            return false;
        }
    }

    public VisibilitySettingDto? GetSetting()
    {
        var setting =  _db.VisibilitySettings.FirstOrDefault(x => x.Id == 1);
        if (setting == null) return null;
        return new VisibilitySettingDto().CopyFrom(setting);
    }
}
