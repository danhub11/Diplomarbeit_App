﻿namespace BrevetBackend.Dtos
{
    public class BrevetWithStatusDto
    {
        public int Id { get; set; }
        public int Distance { get; set; }
        public DateTime Date { get; set; }
        public string? Town { get; set; }
        public string ParticipantStatus { get; set; } = null!;
    }
}