﻿namespace BrevetBackend.Dtos;
public class ParticipantStatusUpdateDto
{
    public int ParticipantId { get; set; }
    public string Status { get; set; } = null!;
}
