﻿namespace BrevetBackend.Dtos;
public class VisibilitySettingDto
{
    public string Setting { get; set; } = null!;
}
