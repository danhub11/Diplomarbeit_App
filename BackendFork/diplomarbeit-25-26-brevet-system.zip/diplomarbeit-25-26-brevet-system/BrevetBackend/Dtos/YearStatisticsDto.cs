﻿namespace BrevetBackend.Dtos;
public class YearStatisticsDto
{
    public int Year { get; set; }
    public int TwoHundresKm { get; set; }
    public int ThreeHundresKm { get; set; }
    public int FourHundresKm { get; set; }
    public int SixHundresKm { get; set; }
    public int ThousandKm { get; set; }
    public int KilometerSum { get; set; }
    public int Finisher { get; set; }
}
