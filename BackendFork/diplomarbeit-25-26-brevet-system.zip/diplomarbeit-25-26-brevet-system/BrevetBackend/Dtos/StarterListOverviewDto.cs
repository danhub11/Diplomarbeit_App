﻿namespace BrevetBackend.Dtos;
public class StarterListOverviewDto
{
    public int Distance { get; set; }
    public DateTime Date { get; set; }
    public int Town { get; set; }
}