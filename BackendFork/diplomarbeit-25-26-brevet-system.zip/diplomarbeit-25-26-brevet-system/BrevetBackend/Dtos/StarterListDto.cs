﻿namespace BrevetBackend.Dtos;

public class StarterListDto
{
    public int Id { get; set; }
    public required string Lastname { get; set; }
    public required string Firstname { get; set; }
    public required string Location { get; set; }
    public required string Country { get; set; }
    public bool? WithMedal { get; set; }
    public string? Status { get; set; }
    public bool? Paid { get; set; }
    public int? HomologationNr { get; set; }
    public int BrevetId { get; set; }
}
