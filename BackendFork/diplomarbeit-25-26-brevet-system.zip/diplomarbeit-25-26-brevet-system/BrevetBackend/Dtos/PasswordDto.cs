﻿namespace BrevetBackend.Dtos;
public class PasswordDto
{
    public string Password { get; set; } = null!;
    public string PasswordCheck { get; set; } = null!;
}
