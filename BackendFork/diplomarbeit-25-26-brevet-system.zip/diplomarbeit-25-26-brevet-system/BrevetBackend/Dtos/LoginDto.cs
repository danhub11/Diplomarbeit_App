﻿namespace BrevetBackend.Dtos;

public class LoginDto
{
    public string LoginId { get; set; } 
    public string Password { get; set; } = null!;
}
