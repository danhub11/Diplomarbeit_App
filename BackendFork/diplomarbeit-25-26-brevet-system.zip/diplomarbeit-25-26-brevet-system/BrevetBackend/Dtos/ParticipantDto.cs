﻿using BrevetDbLib;

namespace BrevetBackend.Dtos;

public class ParticipantDto
{
    public int Id { get; set; }
    public bool? Paid { get; set; }
    public int? HomologationNr { get; set; }
    public bool? WithMedal { get; set; }

    public Randonneur Randonneur { get; set; } = null!;
    public Brevet Brevet { get; set; } = null!;
}
