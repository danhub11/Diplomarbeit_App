﻿namespace BrevetBackend.Dtos
{
    public class BrevetDto
    {
        public int Id { get; set; }
        public int Distance { get; set; }
        public DateTime Date { get; set; }
        public string? Town { get; set; }
    }
}
