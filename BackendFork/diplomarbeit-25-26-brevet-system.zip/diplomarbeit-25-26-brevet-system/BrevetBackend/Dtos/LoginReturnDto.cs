﻿namespace BrevetBackend.Dtos;
public class LoginReturnDto
{
    public int Id { get; set; }
    public bool IsAdmin { get; set; }
}
