﻿namespace BrevetBackend.Dtos;

public class RegisterDto
{
    public int Id { get; set; }
    public string PasswordHash { get; set; } = null!;
    public string RepeatPassword { get; set; } = null!;
    public RandonneurDto Randonneur { get; set; } = null!;
}
